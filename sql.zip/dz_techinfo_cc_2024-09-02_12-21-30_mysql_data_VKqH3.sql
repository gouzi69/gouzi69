-- MySQL dump 10.13  Distrib 5.7.40, for Linux (x86_64)
--
-- Host: localhost    Database: dz_techinfo_cc
-- ------------------------------------------------------
-- Server version	5.7.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dzamount_log`
--

DROP TABLE IF EXISTS `dzamount_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzamount_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount_type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1 余额变动 2 收益变动 3 不影响余额变动',
  `operation_source` tinyint(2) NOT NULL DEFAULT '1' COMMENT '''1 充值 2 加入搭子 3 退出搭子 4 搭子完成收益，5 提现6下单服务 7退出服务8 服务完成 9 搭子分佣 10 服务分佣 11 退出搭子补偿 12  加入社区扣除 13 社区收益 14 社区分佣 15 聊天扣费, 16 手动添加，17 手动扣除 18  查看用户信息扣费 19 查看用户信息扣费退回 20 搭子置顶  21 服务置顶 22 用户拉新''23 充值佣金 24 购买vip 佣金 25 聊天扣费',
  `amount_direction` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 添加 2 扣除',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `correlation_id` int(11) NOT NULL DEFAULT '0',
  `ratio` decimal(12,2) NOT NULL DEFAULT '0.00',
  `handling_fees` decimal(12,2) NOT NULL DEFAULT '0.00',
  `gifts_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '赠送金额',
  `handling_fees_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `original_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzamount_log`
--

LOCK TABLES `dzamount_log` WRITE;
/*!40000 ALTER TABLE `dzamount_log` DISABLE KEYS */;
INSERT INTO `dzamount_log` VALUES (1,1,9999.00,1,16,1,1722483820,0,0.00,0.00,0.00,0.00,0.00);
/*!40000 ALTER TABLE `dzamount_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzcheck_user`
--

DROP TABLE IF EXISTS `dzcheck_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzcheck_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `check_uid` int(11) NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `is_agree` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1申请 2 同意 3 驳回',
  `original_price` decimal(12,2) NOT NULL DEFAULT '2.00',
  `ratio` decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzcheck_user`
--

LOCK TABLES `dzcheck_user` WRITE;
/*!40000 ALTER TABLE `dzcheck_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzcheck_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzcircle`
--

DROP TABLE IF EXISTS `dzcircle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzcircle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `img` text COLLATE utf8_unicode_ci NOT NULL,
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `like_number` int(10) NOT NULL DEFAULT '0',
  `comment_number` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 待审核 2 审核通过 3 驳回  4 删除',
  `longitude` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notice_user` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `authority` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1 所有人 2 关注的人  3 自己',
  `province_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `area_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `remark` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzcircle`
--

LOCK TABLES `dzcircle` WRITE;
/*!40000 ALTER TABLE `dzcircle` DISABLE KEYS */;
INSERT INTO `dzcircle` VALUES (1,1,'金边吊兰怎么样','https://dz.techinfo.cc/storage/uploads/20240801/d2cab86febb0660cbb2891400831a5d5.jpg',1722483950,0,0,2,'106.70925','26.576832','',1,'','','','南明区宏源大厦(市府路北50米)','');
/*!40000 ALTER TABLE `dzcircle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzcircle_comment`
--

DROP TABLE IF EXISTS `dzcircle_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzcircle_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `circle_id` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `like_number` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '发布用户',
  `reply_uid` int(11) NOT NULL DEFAULT '0' COMMENT '被服务用户',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `comment_id` int(11) NOT NULL DEFAULT '0',
  `comment_number` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzcircle_comment`
--

LOCK TABLES `dzcircle_comment` WRITE;
/*!40000 ALTER TABLE `dzcircle_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzcircle_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzcircle_comment_like`
--

DROP TABLE IF EXISTS `dzcircle_comment_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzcircle_comment_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzcircle_comment_like`
--

LOCK TABLES `dzcircle_comment_like` WRITE;
/*!40000 ALTER TABLE `dzcircle_comment_like` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzcircle_comment_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzcircle_like`
--

DROP TABLE IF EXISTS `dzcircle_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzcircle_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `circle_id` int(11) NOT NULL,
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzcircle_like`
--

LOCK TABLES `dzcircle_like` WRITE;
/*!40000 ALTER TABLE `dzcircle_like` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzcircle_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzcommunity`
--

DROP TABLE IF EXISTS `dzcommunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzcommunity` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `desc` text COLLATE utf8_unicode_ci NOT NULL,
  `join_number` int(10) NOT NULL DEFAULT '0',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `allow_join_number` int(10) NOT NULL DEFAULT '0',
  `img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 待审核 2 上架中 3 下架   4 删除 5 驳回',
  `head_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `remark` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sort` tinyint(3) NOT NULL DEFAULT '0',
  `expired_date_time` datetime DEFAULT NULL,
  `expired_state` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='社群';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzcommunity`
--

LOCK TABLES `dzcommunity` WRITE;
/*!40000 ALTER TABLE `dzcommunity` DISABLE KEYS */;
INSERT INTO `dzcommunity` VALUES (1,0,'旅游兴趣群','旅游兴趣群',0,1722484108,500,'https://dz.techinfo.cc/storage/uploads/20240801/e0ff976352cbba83fd5505022f4b9fc7.png',20.00,3,'https://dz.techinfo.cc/storage/uploads/20240801/00c5c7827e986e1aef82b2b51590c261.png','',1,NULL,3);
/*!40000 ALTER TABLE `dzcommunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzcommunity_join`
--

DROP TABLE IF EXISTS `dzcommunity_join`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzcommunity_join` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `community_id` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `original_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzcommunity_join`
--

LOCK TABLES `dzcommunity_join` WRITE;
/*!40000 ALTER TABLE `dzcommunity_join` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzcommunity_join` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzconfig`
--

DROP TABLE IF EXISTS `dzconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzconfig` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` text COLLATE utf8_unicode_ci,
  `remark` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzconfig`
--

LOCK TABLES `dzconfig` WRITE;
/*!40000 ALTER TABLE `dzconfig` DISABLE KEYS */;
INSERT INTO `dzconfig` VALUES (1,'xcx_appid','wx1240ec5397e33758','小程序appid'),(2,'xcx_appSecret','5f2d5d05752569b11118f8a70e7e002d',''),(3,'xcx_mch_id','商户号',''),(4,'xcx_apikey_v3','v3 密钥',''),(5,'xcx_cret_file','',''),(6,'xcx_key_file','',''),(7,'xcx_serial_number','证书序列号',''),(8,'xcx_sp_appid','appid','小程序appid服务商应用ID'),(9,'xcx_m_appSecret','appSecret',''),(10,'xcx_sp_mchid','商户号','服务商户号'),(11,'xcx_sub_appid','子商户应用ID','子商户应用ID'),(12,'xcx_sub_mchid','子商户号','子商户号'),(13,'xcx_m_apikey_v3','apikey_v3',''),(14,'xcx_m_cret_file','',''),(15,'xcx_m_key_file',NULL,''),(16,'xcx_m_serial_number','证书序列号',''),(17,'gzh_appid','wxd5a18ae1c88fd575','公众号 普通商户'),(18,'gzh_appSecret','77035d5275b612ff8ae72a5095669a36',''),(19,'gzh_mch_id','商户号',''),(20,'gzh_apikey_v3','apikey_v3',''),(21,'gzh_cret_file','',''),(22,'gzh_key_file','',''),(23,'gzh_serial_number','证书序列号',''),(24,'gzh_sp_appid','wx1a8ff23726073904','服务商应用ID'),(25,'gzh_m_appSecret','appSecret',''),(26,'gzh_sp_mchid','商户号',''),(27,'gzh_sub_appid','子商户应用ID',''),(28,'gzh_sub_mchid','子商户号',''),(29,'gzh_m_apikey_v3','v3密钥',''),(30,'gzh_m_cret_file','',''),(31,'gzh_m_key_file',NULL,''),(32,'gzh_m_serial_number','证书序列号',''),(33,'pay_type','1','1普通商户2服务商'),(34,'upload_way','1','上传方式 1 本地 2 七牛 3阿里云'),(35,'qiniu_access_key','',''),(36,'qiniu_secret_key','',''),(37,'qiniu_bucket','',''),(38,'qiuniu_file_type','icon,jpg,mp3,mp4,p12,pem,png,rar,jpe',''),(39,'qiuniu_file_size','55555',''),(40,'qiniu_domin','',''),(41,'ali_domain','',''),(42,'ali_access_key','',''),(43,'ali_secret_key','',''),(44,'ali_file_type','doc,gif, ico, icon,jpg,mp3,mp4,p12,pem,png,rar,jpe',''),(45,'ali_file_size','',''),(46,'ali_bucket','',''),(47,'site_domain',NULL,'平台域名'),(48,'platform_name','英孚科技搭子后台','平台名称'),(49,'site_appid','265970972752','c5 授权'),(50,'site_version','1.1.4','版本号'),(51,'distribution_instructions','','分享描述'),(52,'distribution_poster','','分享海报'),(53,'distribution_title','','分享标题'),(54,'logo_img',NULL,''),(55,'platform_email','',''),(56,'platform_phone','',''),(57,'network_record_number','','京公网备案号'),(58,'record_number','','备案号'),(59,'c5_authorization',NULL,''),(60,'login_background_url','',''),(61,'system_logo','',''),(62,'browser_logo','',''),(63,'customer_qr','','客服二维码'),(64,'work_time','',''),(65,'gongzonghao_icon','',''),(66,'invite_img',NULL,'邀请图'),(67,'background_login_img','','后台背景图'),(68,'skill_name','','技术支持'),(69,'gongzonghao_qr_code','',''),(70,'dazi_status','1','0无需后台审核 1 需后台审核'),(71,'dazi_fees','10','搭子完成平台手续费'),(72,'currency_name','钻石','货币名称'),(73,'recharge_ratio','10','充值比例  充值 元获得 多少 平台货币'),(74,'service_status','1','0无需后台审核 1 需后台审核'),(75,'service_fees','10','服务完成平台手续费'),(76,'service_automatic_balance_time',NULL,'服务 自动完成时间'),(77,'circle_status','1','0无需后台审核 1 需后台审核'),(78,'first_commission','10',''),(79,'second_commission','5',''),(80,'withdrawal_condition','0','最低提现'),(81,'everyday_withdrawal_amount','10','每日提现数量'),(82,'everyday_withdrawal_num','10','每日提现次数'),(83,'tencent_map_key','','腾讯地图key'),(84,'community_status','1','0无需后台审核 1 需后台审核'),(85,'community_fees','10','社区手续费'),(86,'dz_signout_rate','1','搭子自动退出手续费'),(87,'chat_price','0','聊天价格'),(88,'chat_level_discount','0','聊天折扣'),(89,'service_level_discount','10','vip 服务 折扣'),(90,'dazi_level_discount','10','搭子折扣'),(91,'community_level_discount','10',''),(92,'withdrawal_mode','3',''),(93,'withdrawal_switch','1',''),(94,'withdrawal_fees_ratio','5',''),(95,'distribution_level','2',''),(96,'distribution_text',NULL,'分销描述'),(97,'user_agreement','<p>开通会员协议</p>',''),(98,'dazi_number','5','0 表示不允许发布  -1 表示不限制'),(99,'circle_number','5',''),(100,'service_number','5',''),(101,'community_number','0',''),(102,'level_dazi_number','80',''),(103,'level_service_number','80',''),(104,'level_circle_number','80',''),(105,'level_community_number','0',''),(106,'level_desc','<p>会员开通描述:</p>',''),(107,'recharge_amount','<p>充值协议:</p>',''),(108,'local_cert','/www/server/panel/vhost/cert/dz.techinfo.cc/fullchain.pem',''),(109,'local_pk','/www/server/panel/vhost/cert/dz.techinfo.cc/privkey.pem',''),(110,'advertisement_id','',''),(111,'gzh_advertisement_id',NULL,''),(112,'currency_img','',''),(113,'platform_address','',''),(114,'customer_service','',''),(115,'ali_duanxin_access_key_id','',''),(116,'ali_duanxin_access_key_secret','',''),(117,'register_notice','',''),(118,'check_phone_price','',''),(119,'dazi_sort_rule','1','1 距离 2 时间'),(120,'dazi_top_number','',''),(121,'dazi_top_price','',''),(122,'dazi_top_level_ratio','',''),(123,'circle_sort_rule','',''),(124,'service_sort_rule','1',''),(125,'service_top_number','',''),(126,'service_top_price','',''),(127,'service_top_level_ratio','',''),(128,'check_phone_level_ratio','',''),(129,'new_user_reward','',''),(130,'dimension','',''),(131,'longitude','',''),(132,'every_day_free_chat','',''),(133,'service_distribution_instructions','服务的描述',''),(134,'service_distribution_poster','服务的海报',''),(135,'service_distribution_title','服务的标题',''),(136,'coterie_distribution_instructions','圈子的描述',''),(137,'coterie_distribution_poster','圈子的海报',''),(138,'coterie_distribution_title','圈子的标题',''),(139,'community_distribution_instructions','社群的描述',''),(140,'community_distribution_poster','社群的海报',''),(141,'community_distribution_title','社群的标题',''),(142,'social_distribution_instructions','社交的描述',''),(143,'social_distribution_poster','社交的海报',''),(144,'social_distribution_title','社交的标题',''),(145,'fill_information_send_coins','0','资料填写送金币数'),(146,'register_send_coins','0','注册赠送金币数'),(147,'attend_register_send_coins','0','拉新送金币数'),(148,'phone_number_authentication_send_coins','0','手机号认证送金币数'),(149,'idCard_number_authentication_send_coins','0','实名认证送金币数'),(150,'ali_idenauthen_appcode',NULL,'阿里服务器云市场中实名认证接口的appcode'),(151,'min_idenauthen_age','18','最小实名认证年龄'),(152,'distributor_desc',NULL,'分销员描述'),(153,'qiniuyun_accessKey',NULL,'七牛云accessKey'),(154,'qiniuyun_secretKey',NULL,'七牛云secretKey');
/*!40000 ALTER TABLE `dzconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzdazi`
--

DROP TABLE IF EXISTS `dzdazi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzdazi` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `people_number` int(10) NOT NULL DEFAULT '0',
  `address` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 男女都行  1  男 2 女',
  `pid_tab` int(10) NOT NULL,
  `son_tab` int(10) NOT NULL,
  `activity_time` bigint(12) NOT NULL DEFAULT '0',
  `expire_time` bigint(12) NOT NULL DEFAULT '0',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `cover_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `wechat` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `img` text COLLATE utf8_unicode_ci NOT NULL COMMENT '多图用 , 切割',
  `describe` text COLLATE utf8_unicode_ci NOT NULL,
  `uid` int(10) NOT NULL,
  `participants_number` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 待审核 2 上架中 3 下架   4 过期 5 完成 6 删除 7 驳回',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `remark` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_start` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0  1 活动正常进行',
  `longitude` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `province_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `area_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address_info` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_top` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 为置顶 1 置顶',
  `woman_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `man_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `woman_number` int(10) NOT NULL DEFAULT '0',
  `man_number` int(10) NOT NULL DEFAULT '0',
  `man_participants_number` int(10) NOT NULL DEFAULT '0',
  `woman_participants_number` int(10) NOT NULL DEFAULT '0',
  `top_expire_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzdazi`
--

LOCK TABLES `dzdazi` WRITE;
/*!40000 ALTER TABLE `dzdazi` DISABLE KEYS */;
INSERT INTO `dzdazi` VALUES (1,'户外烧烤',10,'中山西路',2,6,7,1722580800,1722570000,1722483770,'https://dz.techinfo.cc/storage/uploads/20240801/77173474e5a0e11d861bbb59a029ac67.jpg','','13820478518','户外烧烤','https://dz.techinfo.cc/storage/uploads/20240801/ae7766de53f92e52425a59b89b649c54.jpg','<p>666</p>',1,0,6,0.00,'',0,'106.7098','26.577211','','','','',0,10.00,10.00,5,5,0,0,0),(2,'户外烧烤',6,'中山西路',2,6,7,1722850500,1722764100,1722591351,'https://dz.techinfo.cc/storage/uploads/20240802/f2547af114f9eafd98928223c6acfe72.jpg','','19585801860','666','https://dz.techinfo.cc/storage/uploads/20240802/e4b068ea8e19eae627fe8d6f8d7f432a.jpg','<p>很好玩哦</p>',8,0,2,0.00,'',0,'106.7098','26.577211','','','','',0,10.00,10.00,3,3,0,0,0);
/*!40000 ALTER TABLE `dzdazi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzdazi_join`
--

DROP TABLE IF EXISTS `dzdazi_join`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzdazi_join` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `dazi_id` int(11) NOT NULL DEFAULT '0',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `update_time` bigint(12) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1 正常 2 退出 3 自己 退出  4  到期解散',
  `remark` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `original_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzdazi_join`
--

LOCK TABLES `dzdazi_join` WRITE;
/*!40000 ALTER TABLE `dzdazi_join` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzdazi_join` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzdazi_top_log`
--

DROP TABLE IF EXISTS `dzdazi_top_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzdazi_top_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dazi_id` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `create_time` bigint(12) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `day` tinyint(2) NOT NULL DEFAULT '0',
  `effective_time` bigint(12) NOT NULL DEFAULT '0',
  `ratio` decimal(12,2) NOT NULL DEFAULT '0.00',
  `original_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzdazi_top_log`
--

LOCK TABLES `dzdazi_top_log` WRITE;
/*!40000 ALTER TABLE `dzdazi_top_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzdazi_top_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzdistributor`
--

DROP TABLE IF EXISTS `dzdistributor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzdistributor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `distribution_addr` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '分销地址',
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 审核中 2 审核通过 3 驳回',
  `rationale` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzdistributor`
--

LOCK TABLES `dzdistributor` WRITE;
/*!40000 ALTER TABLE `dzdistributor` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzdistributor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzfollow_user`
--

DROP TABLE IF EXISTS `dzfollow_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzfollow_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '关注用户',
  `follow_uid` int(11) NOT NULL DEFAULT '0' COMMENT '被关注用户',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzfollow_user`
--

LOCK TABLES `dzfollow_user` WRITE;
/*!40000 ALTER TABLE `dzfollow_user` DISABLE KEYS */;
INSERT INTO `dzfollow_user` VALUES (1,8,8,1723281647);
/*!40000 ALTER TABLE `dzfollow_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzhome_menu`
--

DROP TABLE IF EXISTS `dzhome_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzhome_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL,
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1 目录  2 点击事件推送  3 跳转链接 ',
  `url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `sort` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1',
  `key` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzhome_menu`
--

LOCK TABLES `dzhome_menu` WRITE;
/*!40000 ALTER TABLE `dzhome_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzhome_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzhome_module`
--

DROP TABLE IF EXISTS `dzhome_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzhome_module` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '图标',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1启用 0 禁用',
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '页面地址',
  `sort` tinyint(2) NOT NULL DEFAULT '1' COMMENT '排序',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '  1底部菜单',
  `desc` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `update_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzhome_module`
--

LOCK TABLES `dzhome_module` WRITE;
/*!40000 ALTER TABLE `dzhome_module` DISABLE KEYS */;
INSERT INTO `dzhome_module` VALUES (1,'首页','',1,'/H5/index.html#/pages/index/wechatMoments',1,1,'',0,0),(2,'社交圈','',1,'/H5/index.html#/pages/index/listMessages',1,1,'',0,0),(3,'消息','',1,'/H5/index.html#/pagesB/index/listMessages',1,1,'',0,0),(4,'我的','',1,'/H5/index.html#/pagesA/personalCenter/personalCenter',1,1,'',0,0);
/*!40000 ALTER TABLE `dzhome_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzimg_log`
--

DROP TABLE IF EXISTS `dzimg_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzimg_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzimg_log`
--

LOCK TABLES `dzimg_log` WRITE;
/*!40000 ALTER TABLE `dzimg_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzimg_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzlabel`
--

DROP TABLE IF EXISTS `dzlabel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzlabel` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `sort` int(10) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 人物标签 2  搭子标签 3服务标签',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 启用 0 禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzlabel`
--

LOCK TABLES `dzlabel` WRITE;
/*!40000 ALTER TABLE `dzlabel` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzlabel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzlevel`
--

DROP TABLE IF EXISTS `dzlevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzlevel` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `desc` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 启用 2 禁用',
  `level` tinyint(2) NOT NULL DEFAULT '0',
  `price` decimal(12,2) NOT NULL,
  `effective_time` int(10) NOT NULL DEFAULT '1' COMMENT ' 有效时间  按月算',
  `icon` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzlevel`
--

LOCK TABLES `dzlevel` WRITE;
/*!40000 ALTER TABLE `dzlevel` DISABLE KEYS */;
INSERT INTO `dzlevel` VALUES (1,'普通用户','普通用户',1717662850,1,0,0.00,7,''),(2,'vip','11',1717662850,1,1,10.00,15,''),(3,'vip','测试',1719023738,1,1,10.00,10,''),(4,'vip等级','vip等级',1719023774,1,1,10.00,7,'');
/*!40000 ALTER TABLE `dzlevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzlevel_cami`
--

DROP TABLE IF EXISTS `dzlevel_cami`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzlevel_cami` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `level_id` int(11) NOT NULL DEFAULT '0',
  `round_str` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 生效 2 已使用 3 删除',
  `uid` int(11) NOT NULL DEFAULT '0',
  `use_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzlevel_cami`
--

LOCK TABLES `dzlevel_cami` WRITE;
/*!40000 ALTER TABLE `dzlevel_cami` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzlevel_cami` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzlevel_order`
--

DROP TABLE IF EXISTS `dzlevel_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzlevel_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0',
  `level_id` int(11) NOT NULL DEFAULT '0',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 购买 2 卡密兑换',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1 待支付 2支付完成',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `cami_id` int(11) NOT NULL DEFAULT '0',
  `pay_time` bigint(12) NOT NULL DEFAULT '0',
  `pay_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1 小程序 2 公众号',
  `merchant_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 普通商户 2 服务商',
  `effective_time` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzlevel_order`
--

LOCK TABLES `dzlevel_order` WRITE;
/*!40000 ALTER TABLE `dzlevel_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzlevel_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzmenu`
--

DROP TABLE IF EXISTS `dzmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzmenu` (
  `menuId` int(11) NOT NULL AUTO_INCREMENT COMMENT '菜单id',
  `parentId` int(11) NOT NULL DEFAULT '0' COMMENT '上级id, 0是顶级',
  `title` varchar(200) NOT NULL COMMENT '菜单名称',
  `path` varchar(200) DEFAULT NULL COMMENT '菜单路由地址',
  `component` varchar(200) DEFAULT NULL COMMENT '菜单组件地址, 目录可为空',
  `menuType` int(11) DEFAULT '0' COMMENT '类型, 0菜单, 1按钮',
  `sortNumber` int(11) NOT NULL DEFAULT '1' COMMENT '排序号',
  `authority` varchar(200) DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(200) DEFAULT NULL COMMENT '菜单图标',
  `hide` int(11) NOT NULL DEFAULT '0' COMMENT '是否隐藏, 0否, 1是(仅注册路由不显示在左侧菜单)',
  `meta` varchar(800) DEFAULT NULL COMMENT '其它路由元信息',
  `deleted` int(1) NOT NULL DEFAULT '0' COMMENT '是否删除, 0否, 1是',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `openType` tinyint(4) DEFAULT '1' COMMENT '0 禁用 1 启用',
  PRIMARY KEY (`menuId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzmenu`
--

LOCK TABLES `dzmenu` WRITE;
/*!40000 ALTER TABLE `dzmenu` DISABLE KEYS */;
INSERT INTO `dzmenu` VALUES (1,0,'系统管理','/system',NULL,0,11,NULL,'el-icon-setting',0,'{\"badge\": \"New\", \"badgeColor\": \"warning\"}',0,'2020-02-25 20:51:23','2024-07-22 09:12:53',1),(2,1,'用户管理','/system/user','/system/user',0,1,'','el-icon-_user-group',0,NULL,0,'2020-02-25 20:51:55','2024-04-09 01:13:00',1),(3,2,'查询用户',NULL,NULL,1,1,'sys:user:list',NULL,0,NULL,0,'2020-02-25 20:52:06','2024-04-09 01:12:59',1),(4,2,'添加用户','/system/user/add',NULL,1,2,'sys:user:add',NULL,0,NULL,0,'2020-02-25 20:52:26','2024-04-10 18:31:45',1),(5,2,'修改用户','/system/user/update',NULL,1,3,'sys:user:remove',NULL,0,NULL,0,'2020-02-25 20:52:50','2024-04-10 18:31:39',1),(6,2,'删除用户',NULL,NULL,1,4,'sys:user:remove',NULL,0,NULL,0,'2020-02-25 20:53:13','2024-04-09 01:12:45',1),(7,1,'角色管理','/system/role','/system/role',0,2,'','el-icon-postcard',0,NULL,0,'2020-03-12 21:29:08','2024-04-09 01:21:03',1),(8,7,'查询角色','/system/role/page','',1,1,'sys:role:list',NULL,0,NULL,0,'2020-03-12 21:30:41','2024-04-09 02:12:12',1),(9,7,'添加角色','/system/role/add',NULL,1,2,'sys:role:update',NULL,0,NULL,0,'2020-03-14 21:02:07','2024-04-09 02:48:02',1),(10,7,'修改角色','/system/role/edit',NULL,1,3,'',NULL,0,NULL,0,'2020-03-14 21:02:49','2024-04-09 02:48:24',1),(11,7,'删除角色','/system/role/del',NULL,1,4,'sys:role:remove',NULL,0,NULL,0,'2020-03-20 01:58:51','2024-04-09 02:48:28',1),(12,1,'菜单管理','/system/menu','/system/menu',0,3,'','el-icon-s-operation',0,NULL,0,'2020-03-20 09:07:13','2024-04-09 01:21:56',1),(13,12,'查询菜单','',NULL,1,1,'',NULL,0,NULL,0,'2020-03-21 00:43:30','2024-04-09 01:50:04',1),(14,12,'添加菜单','/system/menu/add',NULL,1,2,'',NULL,0,NULL,0,'2020-03-21 00:43:54','2024-04-09 02:29:12',1),(15,12,'修改菜单','/system/menu/edit',NULL,1,3,'sys:menu:update',NULL,0,NULL,0,'2020-03-21 02:24:17','2024-04-09 02:29:13',1),(16,12,'删除菜单','/system/menu/del',NULL,1,4,'',NULL,0,NULL,0,'2020-03-21 02:24:18','2024-04-15 17:47:44',1),(18,0,'用户管理','/user',NULL,0,2,NULL,'el-icon-user',0,NULL,1,'2024-04-08 18:38:27','2024-07-18 01:48:40',1),(19,18,'用户列表','/user/user','/user/user',0,1,NULL,'el-icon-_user-add',0,NULL,1,'2024-04-08 18:43:42','2024-07-18 01:48:36',1),(20,7,'分配权限列表','/system/roleMenu',NULL,1,0,'',NULL,0,NULL,0,'2024-04-10 17:10:27','2024-04-10 18:03:32',1),(21,7,'修改管理员权限','/system/roleMenu/roleMenuEdit',NULL,1,0,NULL,NULL,0,NULL,0,'2024-04-10 18:04:36','2024-04-10 18:06:37',1),(22,19,'查看用户','/user/user',NULL,1,0,'',NULL,0,NULL,1,'2024-04-10 19:21:12','2024-07-18 01:48:27',1),(23,19,'修改密码','/user/user/password',NULL,1,0,'',NULL,0,NULL,1,'2024-04-10 19:35:10','2024-07-18 01:48:21',1),(24,19,'修改用户状态','/user/user/status',NULL,1,0,'',NULL,0,NULL,1,'2024-04-10 19:42:21','2024-07-18 01:48:18',1),(25,7,'修改密码','/system/user/password',NULL,1,1,NULL,NULL,0,NULL,0,'2024-06-08 01:33:49','2024-07-02 07:26:11',1),(26,0,'基础配置','/basicConfiguration','null',0,2,'null','el-icon-_setting',0,NULL,1,'2024-06-18 08:21:37','2024-06-18 08:26:36',1),(27,0,'基础配置','/basicConfiguration',NULL,0,2,NULL,'el-icon-_setting',0,NULL,1,'2024-06-18 08:21:52','2024-06-18 08:26:30',1),(28,0,'基础配置','/basicConfiguration','',0,8,'','el-icon-_setting',0,NULL,0,'2024-06-18 08:26:56','2024-07-22 09:12:23',1),(29,28,'图片配置','/config/index1','/saveSetting',0,0,'','el-icon-picture-outline',0,NULL,0,'2024-06-18 08:30:09','2024-06-18 08:30:09',1),(30,28,'轮播图管理','/basicConfiguration/carouselManagement','/basicConfiguration/carouselManagement',0,1,'','el-icon-picture-outline',0,NULL,0,'2024-06-19 01:30:44','2024-06-19 01:30:44',1),(31,28,'分类管理','/basicConfiguration/classifyList','/basicConfiguration/classifyList',0,1,'','el-icon-_menu',0,NULL,0,'2024-06-19 03:42:33','2024-07-18 02:37:08',1),(32,28,'支付配置','/basicConfiguration/paymentConfiguration','/basicConfiguration/paymentConfiguration',0,0,'','el-icon-remove-outline',0,NULL,0,'2024-06-19 07:30:22','2024-06-19 09:21:03',1),(33,0,'vip等级','/vIpLevel','',0,7,'','el-icon-_integral',0,NULL,0,'2024-06-22 01:23:01','2024-07-22 09:12:18',1),(34,33,'vip等级列表','/vipLevel/vipList','/vipLevel/vipList',0,0,'','el-icon-postcard',0,NULL,0,'2024-06-22 01:23:44','2024-06-22 01:30:24',1),(35,0,'搭子管理','/buildingManagement',NULL,0,1,NULL,'el-icon-data-line',0,NULL,0,'2024-06-22 08:01:59','2024-07-22 09:10:52',1),(36,35,'搭子列表','/buildingManagement/buildingList','/buildingManagement/buildingList',0,0,'','el-icon-_user-group',0,NULL,0,'2024-06-22 08:02:48','2024-06-22 08:02:48',1),(37,35,'搭子订单','/buildingManagement/buildingOrder','/buildingManagement/buildingOrder',0,0,'','el-icon-user',0,NULL,0,'2024-06-22 08:04:48','2024-06-22 08:04:48',1),(38,0,'服务管理','/serviceManagement','',0,2,'','el-icon-_component',0,NULL,0,'2024-06-27 02:05:58','2024-07-22 09:10:58',1),(39,38,'服务列表','/serviceManagement/serviceList','/serviceManagement/serviceList',0,0,'','el-icon-_feedback',0,NULL,0,'2024-06-27 02:06:54','2024-06-27 02:06:54',1),(40,38,'服务订单','/serviceManagement/serviceOrder','/serviceManagement/serviceOrder',0,1,'','el-icon-collection',0,NULL,0,'2024-06-27 02:08:18','2024-06-27 02:08:18',1),(41,0,'用户列表','/userList','/userList',0,5,'','el-icon-_user-group',0,NULL,0,'2024-06-28 03:19:28','2024-07-22 09:11:19',1),(42,0,'圈子管理','/dynamicManagement','',0,3,'','el-icon-_palette',0,NULL,0,'2024-06-28 11:41:42','2024-07-22 09:11:02',1),(43,42,'圈子列表','/dynamicManagement/dynamicList','/dynamicManagement/dynamicList',0,0,'','',0,NULL,0,'2024-06-28 11:42:53','2024-06-28 11:42:53',1),(44,0,'社群管理','/communityManagement ',NULL,0,4,NULL,'el-icon-_school',0,NULL,0,'2024-06-29 09:49:43','2024-07-22 09:11:24',1),(45,44,'社群列表','/communityManagement/communityList','/communityManagement/communityList',0,0,'','el-icon-_nav',0,NULL,0,'2024-07-01 02:29:27','2024-07-01 02:29:27',1),(46,44,'加入社群用户列表','/communityManagement/joinCommunityList','/communityManagement/joinCommunityList',0,0,'','el-icon-_user-group',0,NULL,0,'2024-07-01 07:16:50','2024-07-01 07:17:21',1),(47,44,'社群消息滚动','/communityManagement/communityRolling','/communityManagement/communityRolling',0,2,'','el-icon-_horn',0,NULL,0,'2024-07-01 07:49:38','2024-07-01 07:49:38',1),(48,0,'充值金额管理','/rechargeManagement','',0,10,'','el-icon-_rmb',0,NULL,0,'2024-07-02 02:23:13','2024-07-22 09:12:44',1),(49,48,'充值金额列表','/rechargeManagement/rechargeList','/rechargeManagement/rechargeList',0,0,'','el-icon-_salary',0,NULL,0,'2024-07-02 02:24:13','2024-07-02 02:24:13',1),(50,28,'通知模版','/basicConfiguration/notificationTemplate','/basicConfiguration/notificationTemplate',0,0,'','el-icon-_horn',0,NULL,0,'2024-07-02 06:40:35','2024-07-02 09:29:09',1),(51,0,'分销管理','/distributionManagement',NULL,0,9,NULL,'el-icon-tickets',0,NULL,0,'2024-07-02 09:29:31','2024-07-22 09:12:36',1),(52,51,'分销设置数据','/distributionManagement/settingWithdrawal','/distributionManagement/settingWithdrawal',0,0,'','el-icon-document-copy',0,NULL,0,'2024-07-02 09:30:49','2024-07-02 09:31:55',1),(53,51,'分销配置','/distributionManagement/distributionSettings','/distributionManagement/distributionSettings',0,0,'','el-icon-setting',0,NULL,0,'2024-07-02 09:32:45','2024-07-02 09:33:33',1),(54,51,'分销列表','/distributionManagement/distributionWithdrawal','/distributionManagement/distributionWithdrawal',0,0,'','el-icon-_feedback',0,NULL,0,'2024-07-02 09:33:25','2024-07-02 09:33:25',1),(55,28,'基础配置','/basicConfiguration/basicConfiguration','/basicConfiguration/basicConfiguration',0,0,'','el-icon-_setting',0,NULL,0,'2024-07-03 03:11:53','2024-07-03 03:11:53',1),(56,48,'充值金额订单','/rechargeManagement/rechargeOrder','/rechargeManagement/rechargeOrder',0,1,'','el-icon-_wallet',0,NULL,0,'2024-07-15 08:09:21','2024-07-15 08:09:51',1),(57,0,'数据统计','/dataStatistics','/dataStatistics',0,0,NULL,'el-icon-star-off',0,NULL,0,'2024-07-15 08:58:17','2024-07-22 09:09:35',1),(58,35,'搭子tabs分类','/buildingManagement/buildingClassIfy','/buildingManagement/buildingClassIfy',0,2,'','el-icon-_nav',0,NULL,0,'2024-07-18 02:24:46','2024-07-18 02:24:46',1),(59,38,'服务tabs分类','/serviceManagement/serviceClassIfy','/serviceManagement/serviceClassIfy',0,0,'','el-icon-_component',0,NULL,0,'2024-07-18 02:34:08','2024-07-18 02:34:08',1),(60,28,'阿里云短信配置','/basicConfiguration/aliySmsSettings','/basicConfiguration/aliySmsSettings',0,3,'','el-icon-suitcase-1',0,NULL,0,'2024-07-19 01:22:57','2024-07-19 01:22:57',1),(61,0,'用户申请获取联系方式记录','/applyMyphoneNumber','/applyMyphoneNumber',0,6,'','el-icon-_user-group',0,NULL,0,'2024-07-19 12:13:03','2024-07-22 09:12:29',1),(62,35,'搭子置顶记录','/buildingManagement/topRecord','/buildingManagement/topRecord',0,0,'','el-icon-sort-up',0,NULL,0,'2024-07-22 02:13:03','2024-07-22 02:13:03',1),(63,38,'服务置顶记录','/serviceManagement/topRecord','/serviceManagement/topRecord',0,0,'','el-icon-sort-up',0,NULL,0,'2024-07-22 02:16:21','2024-07-22 02:16:21',1),(64,33,'vip明细记录','/vipLevel/userLevelOrderList','/vipLevel/userLevelOrderList',0,0,'','el-icon-_transfer',0,NULL,0,'2024-07-22 09:09:54','2024-07-22 09:09:54',1),(65,28,'定时任务','/basicConfiguration/timing','/basicConfiguration/timing',0,0,'','el-icon-suitcase',0,NULL,0,'2024-07-22 09:11:42','2024-07-22 09:11:42',1),(66,28,'公众号菜单链接','/basicConfiguration/accountMenuBar','/basicConfiguration/accountMenuBar',0,0,'','el-icon-_integral',0,NULL,0,'2024-07-22 09:13:46','2024-07-22 09:15:59',1),(67,28,'公众号底部菜单栏配置','/basicConfiguration/officialBottomConfiguration','/basicConfiguration/officialBottomConfiguration',0,0,'','el-icon-data-analysis',0,NULL,0,'2024-07-22 09:17:00','2024-07-22 09:17:00',1),(68,28,'菜单栏配置','/basicConfiguration/navigationBarList','/basicConfiguration/navigationBarList',0,5,'','el-icon-_fold',0,NULL,0,'2024-08-09 07:40:03','2024-08-09 07:40:03',1);
/*!40000 ALTER TABLE `dzmenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzmenu_as`
--

DROP TABLE IF EXISTS `dzmenu_as`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzmenu_as` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) DEFAULT NULL,
  `old_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `new_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(11) NOT NULL,
  `state` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzmenu_as`
--

LOCK TABLES `dzmenu_as` WRITE;
/*!40000 ALTER TABLE `dzmenu_as` DISABLE KEYS */;
INSERT INTO `dzmenu_as` VALUES (1,35,'搭子','搭子1',1,1),(2,42,'圈子','朋友圈',2,1),(3,38,'服务','服务',3,1),(4,NULL,'社交','社交',4,1),(5,44,'社群','社群',5,1);
/*!40000 ALTER TABLE `dzmenu_as` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzmessage_template`
--

DROP TABLE IF EXISTS `dzmessage_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzmessage_template` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tid` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '模板id',
  `content` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1 启用',
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reamk` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1公众号消息 2 短信模板 3 小程序',
  `template_name` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzmessage_template`
--

LOCK TABLES `dzmessage_template` WRITE;
/*!40000 ALTER TABLE `dzmessage_template` DISABLE KEYS */;
INSERT INTO `dzmessage_template` VALUES (1,'','',0,0,'dazi_entry','搭子报名','类目 工具  预约/报名  报名进展通知:任务名称->活动时间->新增报名->当前报名人数->温馨提示',3,''),(2,'','',0,0,'release','搭子/圈子/服务/社群  审核通过,下架,驳回 ','类目 生活服务 百货/超市/便利店 信息发布服务状态提醒 服务类型 ->变更状态->通知时间',3,''),(3,'','',0,0,'follow','关注','类目 生活服务 百货/超市/便利店  新粉丝关注提醒  用户->关注时间',3,''),(4,'','',0,0,'consumption','余额消费','类目 生活服务  丽人服务 余额变动通知 消费金额->变动原因->温馨提示->消费时间',3,''),(5,'','',0,0,'recharge','充值','类目 工具 预约/报名 充值金额-> 到账数量 ->赠送金额 ->充值时间',3,''),(6,'','',0,0,'vip','购买vip','类目  生活服务 百货/超市/便利店  实付金额->姓名 ->开通日期->有效期至 ',3,''),(7,'','',0,0,'dazi_entry','搭子报名','类目  工具 预约/报名 收到报名申请通知->报名名称->报名类型->报名人数->申请时间',1,''),(8,'','',0,0,'release','搭子/圈子/服务/社群  审核通过,下架,驳回 ','类目 工具 预约/报名 报名审核结果通知 项目名称-> 用户昵称 ->报名名称->审核结果',1,''),(9,'','',0,0,'consumption','余额消费','类目 生活服务  百货/超市/便利店  消费成功通知 消费项目->消费商品->消费金额->消费时间',1,''),(10,'','',0,0,'recharge','充值','类目 生活服务  丽人服务  充值成功通知  支付金额 ->充值商品 ->到账金额 ->充值时间',1,''),(11,'','',0,0,'vip','购买vip','类目  生活服务 百货/超市/便利店  购买金额->购买时间->到期时间 ',1,''),(12,'','',0,0,' withdrawal','提现成功','类目  生活服务 百货/超市/便利店   提现金额  到账金额 手续费 提现时间',1,''),(13,'','',0,0,'withdrawal','提现成功','类目  生活服务 百货/超市/便利店   提现金额  到账金额 手续费 提现时间',3,''),(14,'','',0,0,'withdrawal','提现成功','提现已到账，到账金额${money}',2,''),(15,'','',0,0,'recharge','充值','充值已到账 充值金额:${money},到账${number}',2,''),(16,'','',0,0,'release','搭子/服务/社群   加入 完成 退出 等通知','${name}已${desc},请注意查看',2,''),(17,'','',0,1,'sms','短信验证码','您的验证码${code}，该验证码5分钟内有效，请勿泄漏于他人！',2,'微聚云科');
/*!40000 ALTER TABLE `dzmessage_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dznotice_message`
--

DROP TABLE IF EXISTS `dznotice_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dznotice_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8_unicode_ci,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '操作用户',
  `receive_uid` int(11) NOT NULL DEFAULT '0' COMMENT '通知用户',
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '1 评论圈子 2点赞圈子  3 取消圈子点赞 4 回复评论 5 点赞评论 6取消点赞 7 系统通知  8  加入搭子  9 踢出搭子 10 退出搭子 11 搭子解散 12 服务下单 13 完成服务订单 14 结算服务订单 15 拒绝服务订单',
  `circle_id` int(11) NOT NULL DEFAULT '0',
  `comment_id` int(11) NOT NULL DEFAULT '0',
  `create_time` bigint(11) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 未读 1 已读 2 已删除',
  `update_time` bigint(12) NOT NULL DEFAULT '0',
  `dazi_id` int(11) NOT NULL DEFAULT '0',
  `service_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dznotice_message`
--

LOCK TABLES `dznotice_message` WRITE;
/*!40000 ALTER TABLE `dznotice_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `dznotice_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzoperate_log`
--

DROP TABLE IF EXISTS `dzoperate_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzoperate_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `operate_id` int(11) NOT NULL DEFAULT '0' COMMENT '操作人id',
  `route` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `method` enum('put','get','delete','post') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `req_data` text COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(11) NOT NULL DEFAULT '0',
  `platform` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzoperate_log`
--

LOCK TABLES `dzoperate_log` WRITE;
/*!40000 ALTER TABLE `dzoperate_log` DISABLE KEYS */;
INSERT INTO `dzoperate_log` VALUES (1,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"hvcfg\",\"tenantId\":1}','111.121.114.119',1721869818,0),(2,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"vhfpz\",\"tenantId\":1}','111.121.114.119',1721959517,0),(3,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"tr3tb\",\"tenantId\":1}','1.204.54.31',1722048599,0),(4,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"mg6nm\",\"tenantId\":1}','1.204.54.31',1722393274,0),(5,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"vaudy\",\"tenantId\":1}','1.204.54.31',1722471441,0),(6,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"2dhmk\",\"tenantId\":1}','1.204.54.31',1722478017,0),(7,1,'/tabClass/addTab','添加tab分类','post','{\"name\":\"\\u9a7e\\u6821\\u54a8\\u8be2\",\"icon\":\"\",\"sort\":\"0\",\"pid\":\"\",\"type\":3,\"label_icon\":\"\",\"type_css\":\"\"}','1.204.54.31',1722478052,0),(8,1,'/tabClass/addTab','添加tab分类','post','{\"name\":\"\\u9910\\u996e\\u52a0\\u76df\",\"icon\":\"\",\"sort\":\"1\",\"pid\":\"\",\"type\":3,\"label_icon\":\"\",\"type_css\":\"\"}','1.204.54.31',1722478061,0),(9,1,'/tabClass/addTab','添加tab分类','post','{\"name\":\"\\u623f\\u4ea7\\u8d44\\u8baf\",\"icon\":\"\",\"sort\":\"2\",\"pid\":\"\",\"type\":3,\"label_icon\":\"\",\"type_css\":\"\"}','1.204.54.31',1722478072,0),(10,1,'/tabClass/addTab','添加tab分类','post','{\"name\":\"\\u6237\\u5916\\u70e7\\u70e4\",\"icon\":\"\",\"sort\":\"0\",\"pid\":\"\",\"type\":1,\"label_icon\":\"https:\\/\\/dz.techinfo.cc\\/images\\/\\u7b2c\\u4e00\\u884c\\u6240\\u6709\\u56fe\\u6807\\/\\u7ec4\\u5408 786.png\",\"type_css\":\"3\"}','1.204.54.31',1722478136,0),(11,1,'/tabClass/editTab','修改tab分类','post','{\"name\":\"\\u6237\\u5916\\u70e7\\u70e4\",\"icon\":\"\",\"sort\":0,\"pid\":\"\",\"type\":1,\"label_icon\":\"https:\\/\\/dz.techinfo.cc\\/images\\/\\u7b2c\\u4e00\\u884c\\u6240\\u6709\\u56fe\\u6807\\/\\u7ec4\\u5408 786.png\",\"type_css\":\"3\",\"id\":4}','1.204.54.31',1722478184,0),(12,1,'/tabClass/editTab','修改tab分类','post','{\"name\":\"\\u6237\\u5916\\u70e7\\u70e4\",\"icon\":\"\",\"sort\":\"1\",\"pid\":\"\",\"type\":1,\"label_icon\":\"https:\\/\\/dz.techinfo.cc\\/images\\/\\u7b2c\\u4e00\\u884c\\u6240\\u6709\\u56fe\\u6807\\/\\u7ec4\\u5408 786.png\",\"type_css\":\"3\",\"id\":4}','1.204.54.31',1722478597,0),(13,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"fai4c\",\"tenantId\":1}','175.7.151.35',1722482529,0),(14,1,'/tabClass/addTab','添加tab分类','post','{\"name\":\"\\u6d4b\\u8bd5\",\"icon\":\"https:\\/\\/dz.techinfo.cc\\/storage\\/uploads\\/20240801\\/7717ea72f3cc24cded6c2776ed1658cc.png\",\"sort\":\"1\",\"pid\":4,\"type\":1,\"label_icon\":\"\",\"type_css\":\"\"}','175.7.151.35',1722482787,0),(15,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"hrycq\",\"tenantId\":1}','1.204.54.31',1722483182,0),(16,1,'/user/authentication','实名认证','post','{\"is_authentication\":2,\"id\":1,\"remark\":null}','1.204.54.31',1722483494,0),(17,1,'/tabClass/updateStatus','修改tab分类状态','post','{\"id\":4,\"status\":2}','1.204.54.31',1722483539,0),(18,1,'/tabClass/updateStatus','修改tab分类状态','post','{\"id\":5,\"status\":2}','1.204.54.31',1722483541,0),(19,1,'/tabClass/addTab','添加tab分类','post','{\"name\":\"\\u6237\\u5916\\u6d3b\\u52a8\",\"icon\":\"\",\"sort\":\"1\",\"pid\":\"\",\"type\":1,\"label_icon\":\"https:\\/\\/dz.techinfo.cc\\/images\\/\\u7b2c\\u4e00\\u884c\\u6240\\u6709\\u56fe\\u6807\\/\\u7ec4\\u5408 786.png\",\"type_css\":\"3\"}','1.204.54.31',1722483563,0),(20,1,'/tabClass/addTab','添加tab分类','post','{\"name\":\"\\u6237\\u5916\\u70e7\\u70e4\",\"icon\":\"https:\\/\\/dz.techinfo.cc\\/storage\\/uploads\\/20240801\\/5bf7bf75ad026d0bfea9ed5c10a7f217.jpeg\",\"sort\":\"1\",\"pid\":6,\"type\":1,\"label_icon\":\"\",\"type_css\":\"\"}','1.204.54.31',1722483592,0),(21,1,'/user/setAmount','修改用户余额','post','{\"balance\":\"9999\",\"id\":1,\"type\":1}','1.204.54.31',1722483820,0),(22,1,'/tabClass/addTab','添加tab分类','post','{\"name\":\"\\u70e7\\u70e4\\u5e97\",\"icon\":\"https:\\/\\/dz.techinfo.cc\\/storage\\/uploads\\/20240801\\/fb5be7a21317ec6543129b11f7e32c49.png\",\"sort\":\"1\",\"pid\":2,\"type\":3,\"label_icon\":\"\",\"type_css\":\"\"}','1.204.54.31',1722484017,0),(23,1,'/addCommunity','添加社群','post','{\"name\":\"\\u65c5\\u6e38\\u5174\\u8da3\\u7fa4\",\"img\":\"https:\\/\\/dz.techinfo.cc\\/storage\\/uploads\\/20240801\\/e0ff976352cbba83fd5505022f4b9fc7.png\",\"head_img\":\"https:\\/\\/dz.techinfo.cc\\/storage\\/uploads\\/20240801\\/00c5c7827e986e1aef82b2b51590c261.png\",\"desc\":\"\\u65c5\\u6e38\\u5174\\u8da3\\u7fa4\",\"allow_join_number\":\"500\",\"price\":\"20\"}','1.204.54.31',1722484108,0),(24,1,'/updateSort','排序','post','{\"id\":1,\"sort\":1}','1.204.54.31',1722484110,0),(25,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"kyyud\",\"tenantId\":1}','1.204.54.31',1722564340,0),(26,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"w3adk\",\"tenantId\":1}','1.204.54.31',1722565760,0),(27,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"5sb3k\",\"tenantId\":1}','1.204.54.31',1722576703,0),(28,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"36ddd\",\"tenantId\":1}','1.204.54.31',1722585897,0),(29,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"vekj4\",\"tenantId\":1}','1.204.54.31',1722591083,0),(30,1,'/upServiceStatus','修改服务状态','post','{\"status\":2,\"id\":1,\"remark\":null}','1.204.54.31',1722591104,0),(31,1,'/upServiceStatus','修改服务状态','post','{\"status\":3,\"id\":1}','1.204.54.31',1722591113,0),(32,1,'/updateDaziStatus','修改搭子状态','post','{\"id\":1,\"status\":6}','1.204.54.31',1722591122,0),(33,1,'/user/authentication','实名认证','post','{\"is_authentication\":2,\"id\":8,\"remark\":null}','1.204.54.31',1722591286,0),(34,1,'/updateDaziStatus','修改搭子状态','post','{\"status\":2,\"id\":2,\"remark\":null}','1.204.54.31',1722591361,0),(35,1,'/upServiceStatus','修改服务状态','post','{\"status\":2,\"id\":2,\"remark\":null}','1.204.54.31',1722591466,0),(36,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"puazs\",\"tenantId\":1}','1.204.54.31',1722645263,0),(37,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":true,\"code\":\"slkke\",\"tenantId\":1}','1.204.54.31',1722671057,0),(38,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"xa56w\",\"tenantId\":1}','175.7.169.45',1723005847,0),(39,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":true,\"code\":\"6ca4w\",\"tenantId\":1}','111.121.123.113',1723260382,0),(40,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"PQPRw\",\"tenantId\":1}','117.188.16.101',1723514192,0),(41,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":true,\"code\":\"tq37m\",\"tenantId\":1}','111.121.123.113',1723523593,0),(42,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"lbeez\",\"tenantId\":1}','111.121.118.22',1724116343,0),(43,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"bkru2\",\"tenantId\":1}','111.121.121.50',1724297383,0),(44,1,'Staff/Login','登录','post','{\"username\":\"superadmin\",\"password\":\"superadmin\",\"remember\":false,\"code\":\"a7eaf\",\"tenantId\":1}','111.121.121.50',1724575548,0);
/*!40000 ALTER TABLE `dzoperate_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzpay_amount`
--

DROP TABLE IF EXISTS `dzpay_amount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzpay_amount` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `create_time` bigint(11) NOT NULL DEFAULT '0',
  `give_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzpay_amount`
--

LOCK TABLES `dzpay_amount` WRITE;
/*!40000 ALTER TABLE `dzpay_amount` DISABLE KEYS */;
INSERT INTO `dzpay_amount` VALUES (1,50.00,500.00,1719888965,55.00,2),(2,10.00,100.00,1719889617,10.00,1),(3,20.00,200.00,1719889627,20.00,1),(4,30.00,300.00,1719889637,30.00,2),(5,40.00,400.00,1719889645,40.00,1),(6,50.00,500.00,1719889653,50.00,1),(7,60.00,600.00,1719889659,60.00,1),(8,70.00,700.00,1719889667,70.00,1),(9,80.00,800.00,1719889673,80.00,1),(10,90.00,900.00,1719889679,90.00,1);
/*!40000 ALTER TABLE `dzpay_amount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzposter`
--

DROP TABLE IF EXISTS `dzposter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzposter` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '链接',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 首页开屏图 2 首页banner 图 3搭子,4 关注',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `sort` tinyint(2) NOT NULL DEFAULT '1' COMMENT '排序',
  `applet_id` int(11) NOT NULL DEFAULT '0',
  `jump_way` tinyint(255) NOT NULL DEFAULT '1' COMMENT ' 1 跳本地 ， 2 跳h5 ，3 跳小程序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='baner 图片';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzposter`
--

LOCK TABLES `dzposter` WRITE;
/*!40000 ALTER TABLE `dzposter` DISABLE KEYS */;
INSERT INTO `dzposter` VALUES (5,'https://n8.weijuyunke.com/2024-06-19/16697202406191022087487.png','',1,1718763731,0,0,0),(6,'https://n8.weijuyunke.com/2024-06-19/f28e0202406191024377370.png','',3,1718763884,0,0,0),(7,'https://n8.weijuyunke.com/2024-06-19/2a507202406191027453983.png','',6,1718764071,0,0,0),(8,'https://n8.weijuyunke.com/2024-06-19/b2e76202406191029589954.png','',4,1718764230,0,0,0),(9,'https://n8.weijuyunke.com/2024-06-19/b15da202406191032021500.png','555',5,1718764330,0,0,2),(10,'https://n8.weijuyunke.com/2024-07-06/f190f202407061413196378.png','',7,1720246404,0,0,0),(11,'https://n8.weijuyunke.com/2024-07-06/0f23a202407061415224455.png','',8,1720246527,0,0,0);
/*!40000 ALTER TABLE `dzposter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzrecharge_order`
--

DROP TABLE IF EXISTS `dzrecharge_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzrecharge_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `uid` int(11) NOT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount` decimal(12,2) NOT NULL,
  `give_amount` decimal(12,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 待支付 2 完成 3 ',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `pay_time` bigint(12) NOT NULL DEFAULT '0',
  `pay_amount_id` int(11) NOT NULL DEFAULT '0',
  `merchant_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 普通商户 2 服务商',
  `pay_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1 小程序 2 公众号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzrecharge_order`
--

LOCK TABLES `dzrecharge_order` WRITE;
/*!40000 ALTER TABLE `dzrecharge_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzrecharge_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzrole`
--

DROP TABLE IF EXISTS `dzrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzrole` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzrole`
--

LOCK TABLES `dzrole` WRITE;
/*!40000 ALTER TABLE `dzrole` DISABLE KEYS */;
INSERT INTO `dzrole` VALUES (1,'管理员',1,1718086843),(2,'23',1,1718086843),(3,'23',1,1718088620);
/*!40000 ALTER TABLE `dzrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzrole_menu`
--

DROP TABLE IF EXISTS `dzrole_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzrole_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `menuId` int(11) DEFAULT '0' COMMENT '菜单id',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `role_id` int(11) NOT NULL DEFAULT '0' COMMENT '角色id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzrole_menu`
--

LOCK TABLES `dzrole_menu` WRITE;
/*!40000 ALTER TABLE `dzrole_menu` DISABLE KEYS */;
INSERT INTO `dzrole_menu` VALUES (1,1,0,2),(2,2,0,2);
/*!40000 ALTER TABLE `dzrole_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzroll_message`
--

DROP TABLE IF EXISTS `dzroll_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzroll_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `desc` text COLLATE utf8_unicode_ci,
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzroll_message`
--

LOCK TABLES `dzroll_message` WRITE;
/*!40000 ALTER TABLE `dzroll_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzroll_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzservice`
--

DROP TABLE IF EXISTS `dzservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzservice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vice_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pid_tab` int(11) NOT NULL DEFAULT '0',
  `son_tab` int(11) NOT NULL DEFAULT '0',
  `describe` text COLLATE utf8_unicode_ci COMMENT '描述',
  `describe_speech` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sex` tinyint(1) NOT NULL DEFAULT '0',
  `address` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `service_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `work_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `label` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cover_img` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 待审核 2 上架中 3 下架 4 驳回',
  `game_level` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uid` int(11) NOT NULL DEFAULT '0',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `complete_number` int(11) NOT NULL DEFAULT '0',
  `remark` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `longitude` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `province_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `area_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address_info` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `order_number` int(5) NOT NULL DEFAULT '0',
  `technology_score_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `voice_score_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `service_score_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `comment_number` int(11) NOT NULL DEFAULT '0',
  `is_top` tinyint(2) NOT NULL DEFAULT '0' COMMENT '1 置顶',
  `top_expire_time` bigint(12) NOT NULL DEFAULT '0' COMMENT '置顶到期时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzservice`
--

LOCK TABLES `dzservice` WRITE;
/*!40000 ALTER TABLE `dzservice` DISABLE KEYS */;
INSERT INTO `dzservice` VALUES (1,'烧烤店','',2,8,'<p>666</p>','',0,'南明区宏源大厦(市府路北50米)','2024-08-01 11:47/2024-08-01 11:47','https://dz.techinfo.cc/storage/uploads/20240801/79180f5adb85f31b5ec65c878b3eedec.jpg','50','好吃','https://dz.techinfo.cc/storage/uploads/20240801/51fdfeb61ed2028602ea8c9cc4853a4b.jpg',1722484069,3,'',1,50.00,0,'','106.70925','26.576832','','','','',0,0.00,0.00,0.00,0,0,0),(2,'烧烤店','666',2,8,'<p>很好的店铺哦</p>','',0,'南明区恒力贵印大厦(法院街西)','2024-08-02 17:37/2024-08-21 23:37','https://dz.techinfo.cc/storage/uploads/20240802/17495ee35d630550b1af4fb866d3b053.jpg','120','好吃的不得了','',1722591457,2,'',8,60.00,0,'','106.70936','26.576834','','','','',0,0.00,0.00,0.00,0,0,0);
/*!40000 ALTER TABLE `dzservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzservice_order`
--

DROP TABLE IF EXISTS `dzservice_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzservice_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uid` int(11) NOT NULL DEFAULT '0',
  `service_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1 待接单 2 接单中 3 完成 4 已结算 5拒绝订单',
  `service_uid` int(11) NOT NULL DEFAULT '0' COMMENT '发布服务的用户id',
  `technology_score` decimal(3,1) NOT NULL DEFAULT '0.0',
  `service_score` decimal(3,1) NOT NULL DEFAULT '0.0',
  `voice_score` decimal(3,1) NOT NULL DEFAULT '0.0',
  `evaluate` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `evaluate_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '评价图',
  `complete_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '完成图',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `create_time` bigint(12) NOT NULL,
  `update_time` bigint(12) NOT NULL DEFAULT '0',
  `remark` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `is_comment` int(11) NOT NULL DEFAULT '0' COMMENT '1 已评价',
  `original_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzservice_order`
--

LOCK TABLES `dzservice_order` WRITE;
/*!40000 ALTER TABLE `dzservice_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzservice_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzservice_top_log`
--

DROP TABLE IF EXISTS `dzservice_top_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzservice_top_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `create_time` bigint(12) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `day` tinyint(2) NOT NULL DEFAULT '0',
  `effective_time` bigint(12) NOT NULL DEFAULT '0',
  `ratio` bigint(12) NOT NULL DEFAULT '0',
  `original_price` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzservice_top_log`
--

LOCK TABLES `dzservice_top_log` WRITE;
/*!40000 ALTER TABLE `dzservice_top_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzservice_top_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzsms_message`
--

DROP TABLE IF EXISTS `dzsms_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzsms_message` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `code` int(4) NOT NULL DEFAULT '0',
  `phone` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL,
  `effective_time` bigint(12) NOT NULL DEFAULT '0',
  `is_use` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 已使用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzsms_message`
--

LOCK TABLES `dzsms_message` WRITE;
/*!40000 ALTER TABLE `dzsms_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzsms_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzstaff_account`
--

DROP TABLE IF EXISTS `dzstaff_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzstaff_account` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salt` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nickname` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `update_time` bigint(12) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 启用2 禁用 3 删除',
  `last_login_ip` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `last_login_time` bigint(12) NOT NULL DEFAULT '0',
  `real_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='管理账号 （后台管理员和商户账号）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzstaff_account`
--

LOCK TABLES `dzstaff_account` WRITE;
/*!40000 ALTER TABLE `dzstaff_account` DISABLE KEYS */;
INSERT INTO `dzstaff_account` VALUES (1,'123213213','superadmin','449dfa03df9fac1eb85572ac66a40e1f','Fsni','',1718076951,0,1,'127.0.0.1',1713839335,'');
/*!40000 ALTER TABLE `dzstaff_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzstaff_role`
--

DROP TABLE IF EXISTS `dzstaff_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzstaff_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `create_time` bigint(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzstaff_role`
--

LOCK TABLES `dzstaff_role` WRITE;
/*!40000 ALTER TABLE `dzstaff_role` DISABLE KEYS */;
INSERT INTO `dzstaff_role` VALUES (1,1,1,1717662850);
/*!40000 ALTER TABLE `dzstaff_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dztab_class`
--

DROP TABLE IF EXISTS `dztab_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dztab_class` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 搭子 2 圈子 3 服务 4 社交 5 关注 6 社群',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 启用 0 禁用',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `pid` int(10) NOT NULL DEFAULT '0',
  `icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sort` int(10) NOT NULL DEFAULT '0',
  `label_icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type_css` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dztab_class`
--

LOCK TABLES `dztab_class` WRITE;
/*!40000 ALTER TABLE `dztab_class` DISABLE KEYS */;
INSERT INTO `dztab_class` VALUES (1,'驾校咨询',3,1,1722478052,0,'',0,'',''),(2,'餐饮加盟',3,1,1722478061,0,'',1,'',''),(3,'房产资讯',3,1,1722478072,0,'',2,'',''),(4,'户外烧烤',1,2,1722478136,0,'',1,'https://dz.techinfo.cc/images/第一行所有图标/组合 786.png','3'),(5,'测试',1,2,1722482787,4,'https://dz.techinfo.cc/storage/uploads/20240801/7717ea72f3cc24cded6c2776ed1658cc.png',1,'',''),(6,'户外活动',1,1,1722483563,0,'',1,'https://dz.techinfo.cc/images/第一行所有图标/组合 786.png','3'),(7,'户外烧烤',1,1,1722483592,6,'https://dz.techinfo.cc/storage/uploads/20240801/5bf7bf75ad026d0bfea9ed5c10a7f217.jpeg',1,'',''),(8,'烧烤店',3,1,1722484017,2,'https://dz.techinfo.cc/storage/uploads/20240801/fb5be7a21317ec6543129b11f7e32c49.png',1,'','');
/*!40000 ALTER TABLE `dztab_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dztiming`
--

DROP TABLE IF EXISTS `dztiming`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dztiming` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `desc` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dztiming`
--

LOCK TABLES `dztiming` WRITE;
/*!40000 ALTER TABLE `dztiming` DISABLE KEYS */;
INSERT INTO `dztiming` VALUES (1,'搭子到期结算','/think dazi','每分钟一次'),(2,'会员到期','/think level','每分钟一次'),(3,'搭子，服务置顶到期','/think topexpire','每分钟一次');
/*!40000 ALTER TABLE `dztiming` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzuser`
--

DROP TABLE IF EXISTS `dzuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzuser` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '电话号码',
  `real_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sex` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1男 2 女',
  `avatar` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `invite_code` varchar(8) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 启用 0 禁用',
  `last_login_ip` varchar(50) COLLATE utf8_unicode_ci DEFAULT '',
  `register_ip` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '注册ip',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `update_time` bigint(12) NOT NULL DEFAULT '0',
  `last_login_time` bigint(12) NOT NULL DEFAULT '0',
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '上级id',
  `pids` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT '全部上级',
  `level_id` int(11) NOT NULL DEFAULT '0' COMMENT '会员等级',
  `level_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '等级名称',
  `birthday` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '生日',
  `province_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `area_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone_area` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '区号',
  `longitude` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_gzh_id` int(11) NOT NULL DEFAULT '0',
  `user_xcx_id` int(11) NOT NULL DEFAULT '0',
  `follow` int(10) NOT NULL DEFAULT '0',
  `fans` int(10) NOT NULL DEFAULT '0',
  `total_income` decimal(12,2) NOT NULL DEFAULT '0.00',
  `dazi_income` decimal(12,2) NOT NULL DEFAULT '0.00',
  `service_income` decimal(12,2) NOT NULL DEFAULT '0.00',
  `community_income` decimal(12,2) NOT NULL DEFAULT '0.00',
  `first_commission_income` decimal(12,2) NOT NULL DEFAULT '0.00',
  `second_commission_income` decimal(12,2) NOT NULL DEFAULT '0.00',
  `surplus_income` decimal(12,2) NOT NULL DEFAULT '0.00',
  `id_card_front` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `id_card_back` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `id_card_number` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_authentication` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未认证 1 审核中 2 认证通过 ',
  `withdrawn_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `height` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `school` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `speech` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '语音介绍',
  `img` text COLLATE utf8_unicode_ci,
  `label` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sort` int(11) NOT NULL DEFAULT '0',
  `service_number` int(11) NOT NULL DEFAULT '0',
  `introduce` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `authentication_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cover_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `age` int(3) NOT NULL DEFAULT '0',
  `background_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_online` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 在线',
  `remark` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vip_income` decimal(12,2) NOT NULL DEFAULT '0.00',
  `invite_xcx_url` longtext COLLATE utf8_unicode_ci,
  `disable` tinyint(4) DEFAULT '1' COMMENT '0 禁用 1 启用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzuser`
--

LOCK TABLES `dzuser` WRITE;
/*!40000 ALTER TABLE `dzuser` DISABLE KEYS */;
INSERT INTO `dzuser` VALUES (8,'Loch','13820478518','张建楠',1,'https://dz.techinfo.cc/storage/uploads/20240802/6a39ad1f2b83f4358e57b5688c0e347e.png','rjnmbm',1,'111.121.121.50','220.197.4.243',1722591042,0,1724309358,0.00,0,'0',1,'普通用户','1990-08-02','','','','','','106.63024','26.64702',0,7,1,1,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'https://dz.techinfo.cc/storage/uploads/20240802/66fcd5798efa07c54dd2bf34077e0b90.jpg','https://dz.techinfo.cc/storage/uploads/20240802/24215d4555d581b171cc0e6835d24e0e.jpg','120222199006281833',2,0.00,'187','北科大','','https://dz.techinfo.cc/storage/uploads/20240802/7b90dafb97a52ef29b5c68fb85bba3de.jpg','国服大神',0,0,'没什么特别','https://dz.techinfo.cc/storage/uploads/20240802/4d9841f3650d1a0a311e181383af6f10.jpg','https://dz.techinfo.cc/storage/uploads/20240802/24fafee91ad022f7c21d1c644fa015b8.jpg',33,'https://dz.techinfo.cc/storage/uploads/20240802/9b14411d03e0762b609a65f95b97a8fe.jpg',1,'',0.00,'data:image/jpeg;base64,eyJlcnJjb2RlIjo0MTAzMCwiZXJybXNnIjoiaW52YWxpZCBwYWdlIHJpZDogNjZhY2E3NmMtNDgyYjk5ZmItMmI5YjlkYTcifQ==',1),(10,'傻逼','','',1,'https://dz.techinfo.cc/storage/uploads/20240803/27bfd6a651b2c8f0b08c2c74393f0281.jpg','e9e6wi',1,'36.43.18.216','36.43.18.216',1722648274,0,1722648305,0.00,0,'0',1,'普通用户','','','','','','','108.881086','34.255014',0,9,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'','','',0,0.00,'','','',NULL,'',0,0,'','','',0,'',1,'',0.00,'data:image/jpeg;base64,eyJlcnJjb2RlIjo0MTAzMCwiZXJybXNnIjoiaW52YWxpZCBwYWdlIHJpZDogNjZhZDg2ZGQtMTcxMDY2YWEtMTY1MTdmYmYifQ==',1),(11,'售后服务张','','',1,'https://dz.techinfo.cc/storage/uploads/20240803/eeea97781a30cd6e8c536363c068a26e.jpg','alm1ed',1,'223.147.208.192','124.232.57.22',1722648275,0,1723004088,0.00,0,'0',1,'普通用户','','','','','','','111.621574','26.429946',0,10,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'','','',0,0.00,'','','',NULL,'',0,0,'','','',0,'',1,'',0.00,'data:image/jpeg;base64,eyJlcnJjb2RlIjo0MTAzMCwiZXJybXNnIjoiaW52YWxpZCBwYWdlIHJpZDogNjZhZDg2ZGMtNmYxZjkyMzgtNGViMWJlNWIifQ==',1),(13,'习主席','','',2,'https://dz.techinfo.cc/storage/uploads/20240803/fd43fe6617c495ecf0938ffc9c5f9e6e.jpg','6jtbqq',1,'220.197.21.57','220.197.21.57',1722648842,0,1722648842,0.00,0,'0',1,'普通用户','','','','','','','','',0,12,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'','','',0,0.00,'','','',NULL,'',0,0,'','','',0,'',1,'',0.00,'data:image/jpeg;base64,eyJlcnJjb2RlIjo0MTAzMCwiZXJybXNnIjoiaW52YWxpZCBwYWdlIHJpZDogNjZhZDkyY2MtNWY2OTE4ZDQtNjRlODk2NDIifQ==',1),(14,'到底','','',1,'https://dz.techinfo.cc/storage/uploads/20240803/a6ae353c2057c910ce71b694a60dcdb5.png','slnsvr',1,'59.36.121.176','59.36.121.176',1722672593,0,1722672593,0.00,0,'0',1,'普通用户','','','','','','','','',0,13,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'','','',0,0.00,'','','',NULL,'',0,0,'','','',0,'',1,'',0.00,'data:image/jpeg;base64,eyJlcnJjb2RlIjo0MTAzMCwiZXJybXNnIjoiaW52YWxpZCBwYWdlIHJpZDogNjZhZjQwMDMtNjI2OGQyMWQtNjczNDMxMmQifQ==',1),(15,'测试','','',1,'https://dz.techinfo.cc/storage/uploads/20240807/46ac6949f35f287884a9b9d4d3ff3f0f.jpeg','finkii',1,'175.7.169.45','175.7.169.45',1723002299,0,1723003796,0.00,0,'0',1,'普通用户','','','','','','','111.62181','26.430647',0,14,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'','','',0,0.00,'','','',NULL,'',0,0,'','','',0,'',1,'',0.00,'data:image/jpeg;base64,eyJlcnJjb2RlIjo0MTAzMCwiZXJybXNnIjoiaW52YWxpZCBwYWdlIHJpZDogNjZiMmZiOWMtMDk4MzY2ZDktMGI1ODU0YTgifQ==',1),(16,'-','','',2,'https://dz.techinfo.cc/storage/uploads/20240807/409acf57573de1c3d621ed518a2c886a.jpg','71yam5',1,'175.7.169.45','175.7.169.45',1723005754,0,1723023779,0.00,15,'0,15',1,'普通用户','','','','','','','111.59244','26.46098',0,15,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'','','',0,0.00,'','','',NULL,'',0,0,'','','',0,'',1,'',0.00,'data:image/jpeg;base64,eyJlcnJjb2RlIjo0MTAzMCwiZXJybXNnIjoiaW52YWxpZCBwYWdlIHJpZDogNjZiMmZiOWItMDNiZGY0Y2UtNjU5MjRiYTUifQ==',1);
/*!40000 ALTER TABLE `dzuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzuser_chat`
--

DROP TABLE IF EXISTS `dzuser_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzuser_chat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `receive_uid` int(11) NOT NULL DEFAULT '0' COMMENT '接收用户',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `is_remove` tinyint(2) NOT NULL DEFAULT '0' COMMENT '1 对方移除',
  `update_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzuser_chat`
--

LOCK TABLES `dzuser_chat` WRITE;
/*!40000 ALTER TABLE `dzuser_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzuser_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzuser_commission`
--

DROP TABLE IF EXISTS `dzuser_commission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzuser_commission` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `trigger_uid` int(11) NOT NULL DEFAULT '0' COMMENT '来源用户id',
  `receive_uid` int(11) NOT NULL DEFAULT '0' COMMENT '接收用户',
  `level` tinyint(1) NOT NULL DEFAULT '1',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `ratio` decimal(12,2) NOT NULL DEFAULT '0.00',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 搭子 2 服务 3充值vip 4  推新 5 充值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzuser_commission`
--

LOCK TABLES `dzuser_commission` WRITE;
/*!40000 ALTER TABLE `dzuser_commission` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzuser_commission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzuser_gzh`
--

DROP TABLE IF EXISTS `dzuser_gzh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzuser_gzh` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '0',
  `unionid` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzuser_gzh`
--

LOCK TABLES `dzuser_gzh` WRITE;
/*!40000 ALTER TABLE `dzuser_gzh` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzuser_gzh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzuser_level`
--

DROP TABLE IF EXISTS `dzuser_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzuser_level` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `start_time` bigint(12) NOT NULL DEFAULT '0',
  `level_id` int(11) NOT NULL DEFAULT '0',
  `end_time` bigint(12) NOT NULL,
  `level` int(5) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 有效  2 过期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzuser_level`
--

LOCK TABLES `dzuser_level` WRITE;
/*!40000 ALTER TABLE `dzuser_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzuser_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzuser_message`
--

DROP TABLE IF EXISTS `dzuser_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzuser_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_uid` int(11) NOT NULL DEFAULT '0',
  `receive_uid` int(11) NOT NULL DEFAULT '0',
  `content` text COLLATE utf8_unicode_ci,
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 已读',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `original_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `imgWidth` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `imgHeight` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzuser_message`
--

LOCK TABLES `dzuser_message` WRITE;
/*!40000 ALTER TABLE `dzuser_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzuser_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzuser_token`
--

DROP TABLE IF EXISTS `dzuser_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzuser_token` (
  `uid` int(11) NOT NULL DEFAULT '0',
  `token` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `effective_time` bigint(12) NOT NULL,
  `login_ip` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 用户  2 商户  3 后台'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzuser_token`
--

LOCK TABLES `dzuser_token` WRITE;
/*!40000 ALTER TABLE `dzuser_token` DISABLE KEYS */;
INSERT INTO `dzuser_token` VALUES (1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE4Njk4MTgsIm5iZiI6MTcyNDQ2MTgxOCwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.ZBe5YqUx_LFDdeP2-3TM1-W1ora5HiF_U7JymLk2wLw',1721869818,1724461818,'111.121.114.119',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE4NzEzNzQsIm5iZiI6MTc1MzQwNzM3NCwidWlkIjoxfQ.hE97zqYNsMrjhR0xCeg5NrcSlsXCWb5Cmi0KrlorYdU',1721871374,1753407374,'111.121.114.119',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE4NzE5MzEsIm5iZiI6MTc1MzQwNzkzMSwidWlkIjoxfQ.oCtokCitQP6KImIQGhx2ZEPEF8u0jsXwAMJndm0LRdc',1721871931,1753407931,'111.121.114.119',1),(2,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE4NzE5NjcsIm5iZiI6MTc1MzQwNzk2NywidWlkIjoyfQ.iANel7GK5p7xykd60RjQw-8MObazSRgy4OAsbB-llzw',1721871967,1753407967,'36.40.189.227',1),(3,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE4NzE5NjcsIm5iZiI6MTc1MzQwNzk2NywidWlkIjozfQ.KTsUjRpPgi_-kzCqMbRNsbaIcD1QJHZ90VQBDtt2Gtk',1721871967,1753407967,'36.40.189.227',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE5NTk1MTcsIm5iZiI6MTcyNDU1MTUxNywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.O0eBtD7WkEmtFmRYukG9wtSsE0hgwx7yOsVCFevxmLE',1721959517,1724551517,'111.121.114.119',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE5NjAwMDYsIm5iZiI6MTc1MzQ5NjAwNiwidWlkIjoxfQ.NzQ40s6LxGXFKdlOr14YtYiUkvo2ZrXelhyEe4FZ7u4',1721960006,1753496006,'111.121.114.119',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE5NjAwNjIsIm5iZiI6MTc1MzQ5NjA2MiwidWlkIjoxfQ.M9LgyhLsBlpF3EGSyjE8WakPD117boL0Rw2qrfnNeWM',1721960062,1753496062,'111.121.114.119',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE5NjAxOTAsIm5iZiI6MTc1MzQ5NjE5MCwidWlkIjoxfQ.pCHDqBFNeE7B4IjpNfAKERIYYRGqdComkG5xHaTFB3I',1721960190,1753496190,'111.121.114.119',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE5ODc0MzgsIm5iZiI6MTc1MzUyMzQzOCwidWlkIjoxfQ.GChpnwgMRUpZMdVGwhFohgoA3NpVQEOP5Swx7RJgKpk',1721987438,1753523438,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE5OTMyODAsIm5iZiI6MTc1MzUyOTI4MCwidWlkIjoxfQ.ZmXM9oVsCmLKxczZjBbvkZykTLXeXykctm7nCxw4zH8',1721993280,1753529280,'220.197.5.140',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjE5OTM1NTEsIm5iZiI6MTc1MzUyOTU1MSwidWlkIjoxfQ.8z7cIgzUCEQTV6Car7R6x5JTZk1D2qrqadHNnAQJsGQ',1721993551,1753529551,'220.197.5.140',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjIwNDc1MDIsIm5iZiI6MTc1MzU4MzUwMiwidWlkIjoxfQ.ckNpKjrsO04ipJgy8EsLwCDSslueBDHc2xvhQ4VkDhw',1722047502,1753583502,'220.197.20.108',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjIwNDg1OTksIm5iZiI6MTcyNDY0MDU5OSwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.JWZMcBQfwDrEUCYcBRcYFNirk77hgcAToLfyA4tPD88',1722048599,1724640599,'1.204.54.31',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjIzOTMyNzQsIm5iZiI6MTcyNDk4NTI3NCwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.argGeqUCh_F8wDD61GgcSLoR82vr8Wz8tpYzUo5kso0',1722393274,1724985274,'1.204.54.31',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjIzOTM1MTcsIm5iZiI6MTc1MzkyOTUxNywidWlkIjoxfQ.QjIZy_ea6sqPdTs6n2AtUnyxIbUkUQ5sYeyovjdcacM',1722393517,1753929517,'220.197.20.198',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjIzOTM1NzYsIm5iZiI6MTc1MzkyOTU3NiwidWlkIjoxfQ.vIyktwLPGIwEeM43Ti8xOs_2V98dTYrpdI3-jMkJqx0',1722393576,1753929576,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjIzOTY0MTUsIm5iZiI6MTc1MzkzMjQxNSwidWlkIjoxfQ.e4l6p8D3mv3z784AX_KF5El8xHY2XqCoYb0Qr_YtVQ8',1722396415,1753932415,'220.197.20.198',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjIzOTc4MDcsIm5iZiI6MTc1MzkzMzgwNywidWlkIjoxfQ.xHXUFmjgDgS9Pd4EA5KYRPx68Cz5l4Gj94T3TPFSxGc',1722397807,1753933807,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0MDEwNDEsIm5iZiI6MTc1MzkzNzA0MSwidWlkIjoxfQ.oZ5HA-Az8ZUwxdwyTXbkk6yxQjG1B2yrLM2PEgrjV5E',1722401041,1753937041,'220.197.20.198',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0MTI1ODgsIm5iZiI6MTc1Mzk0ODU4OCwidWlkIjoxfQ.20GfaFtJtg3MxXdYasVeo5vTiCFnXDHnt2maMvd6WUw',1722412588,1753948588,'220.197.20.198',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0NzE0NDEsIm5iZiI6MTcyNTA2MzQ0MSwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.pO6Pqa-6ISFwke0P-wJlUk-KvqJBYE1CMtmQnEwLJMw',1722471441,1725063441,'1.204.54.31',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0NzgwMTcsIm5iZiI6MTcyNTA3MDAxNywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.B741JrcUTdJatO0ZEvjQhIINEJBTbP25wrlV584MBY4',1722478017,1725070017,'1.204.54.31',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0NzgwOTMsIm5iZiI6MTc1NDAxNDA5MywidWlkIjoxfQ.qNrd-bZdBz4ePEZJ5JhvGuC51PyFZSfn7pa0_Deqbyg',1722478093,1754014093,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0NzgxNDUsIm5iZiI6MTc1NDAxNDE0NSwidWlkIjoxfQ.0YKn2b9aoTpt1P_axal3gFNppnnPSBsIFVkfIa4_lls',1722478145,1754014145,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0NzgzNzIsIm5iZiI6MTc1NDAxNDM3MiwidWlkIjoxfQ.uGkFCuEMvOvwcKM_Jhkaxmxf1uLrW09HdI6E75iblok',1722478372,1754014372,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODI1MjksIm5iZiI6MTcyNTA3NDUyOSwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.R8_oqSnqmQzb1l2KNPUl2Z5I8lJnXdQluNgUVDjIXzk',1722482529,1725074529,'175.7.151.35',3),(4,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODI1NDgsIm5iZiI6MTc1NDAxODU0OCwidWlkIjo0fQ.qrq3El8ZvQjYEtJ01O4bRMHEAA1kaYIwND8_i0spos4',1722482548,1754018548,'175.7.151.35',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODI2NzUsIm5iZiI6MTc1NDAxODY3NSwidWlkIjoxfQ.BV-5GVBG3hJ9XgbvQPsUtqxA4g4Ukr8u2Seq-iLCySQ',1722482675,1754018675,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODMxODIsIm5iZiI6MTcyNTA3NTE4Miwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.W6FVsD2fVSDQqqT8gQTLOHHsvcjVkzxt3ENBfNfyFwM',1722483182,1725075182,'1.204.54.31',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODM5NzUsIm5iZiI6MTc1NDAxOTk3NSwidWlkIjoxfQ.9b_m-c3Y2batA6QTg4x9-HqZZSNnYpYkh1WpgqVZm74',1722483975,1754019975,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODQxMTksIm5iZiI6MTc1NDAyMDExOSwidWlkIjoxfQ.4vcXftBHnCrxnpFMPcwheJWJprJK1tMgzTBjJ_sbe5k',1722484119,1754020119,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODQxODAsIm5iZiI6MTc1NDAyMDE4MCwidWlkIjoxfQ.ZOiSWWf4kv4MK93heouhe5VizA8bilB0OyJysm58yMI',1722484180,1754020180,'1.204.54.31',1),(5,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODUzMzQsIm5iZiI6MTc1NDAyMTMzNCwidWlkIjo1fQ.VFspWe9FjGB9x4ypOjsSxAZbIIVxVm0HMaOX3z3_dSU',1722485334,1754021334,'59.36.121.176',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODYyMTQsIm5iZiI6MTc1NDAyMjIxNCwidWlkIjoxfQ.-qn5Xh4GuRuPaOlmsFFjBYdDuJi7MwDkNLroHl0y9yc',1722486214,1754022214,'1.204.54.31',1),(6,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI0ODc1NjksIm5iZiI6MTc1NDAyMzU2OSwidWlkIjo2fQ.OxIwbXYh-IfKow2xJT2k8WOW-XRSBjFVxB662Xbvl10',1722487569,1754023569,'59.36.121.176',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1NjQzNDAsIm5iZiI6MTcyNTE1NjM0MCwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.dGNAxA8VV0YB1ASb4YfdS89qkeotIrTdXKERMrrdLBE',1722564340,1725156340,'1.204.54.31',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1NjQ1NTEsIm5iZiI6MTc1NDEwMDU1MSwidWlkIjoxfQ.wdth4t50WOpZtv5lu2DzE4D91K77vG9SAdtdx8h5xnI',1722564551,1754100551,'1.204.54.31',1),(7,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1NjU2NzQsIm5iZiI6MTc1NDEwMTY3NCwidWlkIjo3fQ.Gwvyz217t5D2PJKwXLaT8GlzbN-LvGeBAOtCdfX3C7E',1722565674,1754101674,'221.182.3.211',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1NjU3NjAsIm5iZiI6MTcyNTE1Nzc2MCwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.p5Hfkh-aiM2jsKebHriqJ9EZph8WCF9D2TyVveKaFXY',1722565760,1725157760,'1.204.54.31',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1NzY3MDMsIm5iZiI6MTcyNTE2ODcwMywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.yeJBnvgMLTHWf8KjDl0qIuFgf6Xbs8OsY-8c1qL6jzg',1722576703,1725168703,'1.204.54.31',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1ODU4OTcsIm5iZiI6MTcyNTE3Nzg5Nywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9._9lE-fnotnA0ZX0A9in8WOWUAuAtjDUEL_159DrZcbg',1722585897,1725177897,'1.204.54.31',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1ODYwOTgsIm5iZiI6MTc1NDEyMjA5OCwidWlkIjoxfQ.FrGc1NQbgmeBODWVAWr9FwhriPJaTcSqaTBfrnun9e8',1722586098,1754122098,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1ODYxOTksIm5iZiI6MTc1NDEyMjE5OSwidWlkIjoxfQ.4KvTPCx5agC4nUNre5wkWn-r4LVLGN5jnKQ7BP-wBW4',1722586199,1754122199,'1.204.54.31',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1ODc0NzQsIm5iZiI6MTc1NDEyMzQ3NCwidWlkIjoxfQ.oNsHls6ZGD_i6gDHpGi6-ARgWX2AnT6Da1Vm7pNbiYM',1722587474,1754123474,'220.197.4.243',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1OTEwNDIsIm5iZiI6MTc1NDEyNzA0MiwidWlkIjo4fQ.yVec8Lm8r4soAAvoHYGTcr4NNwOfE-ykelckWRmu_X8',1722591042,1754127042,'220.197.4.243',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1OTEwODMsIm5iZiI6MTcyNTE4MzA4Mywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.HKnoFWZqDmfK8uUYRrvgRf2og8xtkAOQVdU6H1D7sko',1722591083,1725183083,'1.204.54.31',3),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1OTE1NzgsIm5iZiI6MTc1NDEyNzU3OCwidWlkIjo4fQ.M_itaVrvDP61_qybW8nOuqxA3eBX5NoDXhfkJytaGFM',1722591578,1754127578,'1.204.54.31',1),(9,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI1OTI2NjksIm5iZiI6MTc1NDEyODY2OSwidWlkIjo5fQ.Vla5ySbPgSMZux8RRoh7piyE8SieKD5cgxAiEuaWPT4',1722592669,1754128669,'59.36.121.176',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDUyNjMsIm5iZiI6MTcyNTIzNzI2Mywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.eIEhnjVTDaeaFTAlLpwCUEGaaweu4EFjpUMU-lfZ3h8',1722645263,1725237263,'1.204.54.31',3),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDc4MTQsIm5iZiI6MTc1NDE4MzgxNCwidWlkIjo4fQ.SbG8MBCrv4nACmiG8osgJp-nBSux2D7gWC41dLUocMk',1722647814,1754183814,'1.204.54.31',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDc4MTYsIm5iZiI6MTc1NDE4MzgxNiwidWlkIjo4fQ.rmquNyxpSLYNBP5OrI16L-w86xTXB7diK-bBSPa_80o',1722647816,1754183816,'1.204.54.31',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDgyMzMsIm5iZiI6MTc1NDE4NDIzMywidWlkIjo4fQ.H747lVaAaDjqCeb461AQYHKguKK06aEfYvwhrKYjasg',1722648233,1754184233,'1.204.54.31',1),(10,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDgyNzQsIm5iZiI6MTc1NDE4NDI3NCwidWlkIjoxMH0.LdJLVVEWRU-GgymV61w49Fe_BCm63HnJab1oKeIPg54',1722648274,1754184274,'36.43.18.216',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDgyNzUsIm5iZiI6MTc1NDE4NDI3NSwidWlkIjoxMX0.aQusXnKtGYifFbHGf00Z4YdjVyIDunYEJcP8qIujm1U',1722648275,1754184275,'124.232.57.22',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDgyNzcsIm5iZiI6MTc1NDE4NDI3NywidWlkIjoxMX0.PkGhFhuy5d7bo4EWoOhsxApLS_syalfRng7v9r7i3Fo',1722648277,1754184277,'124.232.57.22',1),(10,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDgzMDUsIm5iZiI6MTc1NDE4NDMwNSwidWlkIjoxMH0.PskiXb9oJ2RR7VNKdXRUJePh9xsLvFaNtp7ltobW0h8',1722648305,1754184305,'36.43.18.216',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDgzODQsIm5iZiI6MTc1NDE4NDM4NCwidWlkIjoxMX0.GccfXx-LCv1LJ_iS_sZh6V9jTWF1Prq416-aw19Ycvs',1722648384,1754184384,'124.232.57.22',1),(12,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDg1MjUsIm5iZiI6MTc1NDE4NDUyNSwidWlkIjoxMn0.oxJNH6gRZrQ_z5py0RcMo3cO7rp4wuE8no9J1OQRDhg',1722648525,1754184525,'220.197.21.57',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDg3MjcsIm5iZiI6MTc1NDE4NDcyNywidWlkIjoxMX0.FpZ4D_rkNK8ntlQBxGFin2Thq-lZV0M1wUZqyMC3vD8',1722648727,1754184727,'124.232.57.22',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDg3MjcsIm5iZiI6MTc1NDE4NDcyNywidWlkIjoxMX0.FpZ4D_rkNK8ntlQBxGFin2Thq-lZV0M1wUZqyMC3vD8',1722648727,1754184727,'124.232.57.22',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDg3MjgsIm5iZiI6MTc1NDE4NDcyOCwidWlkIjoxMX0.gXdkPAABTf31T6UWSHswEsgotUImh9XUORurEHHnQcQ',1722648728,1754184728,'124.232.57.22',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDg3MjgsIm5iZiI6MTc1NDE4NDcyOCwidWlkIjoxMX0.gXdkPAABTf31T6UWSHswEsgotUImh9XUORurEHHnQcQ',1722648728,1754184728,'124.232.57.22',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDg3MjgsIm5iZiI6MTc1NDE4NDcyOCwidWlkIjoxMX0.gXdkPAABTf31T6UWSHswEsgotUImh9XUORurEHHnQcQ',1722648728,1754184728,'124.232.57.22',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDg3ODksIm5iZiI6MTc1NDE4NDc4OSwidWlkIjoxMX0.CkUN2-Q8wUzHGk221YBL5vzIpp7Pex_CZGPcv1YkOA8',1722648789,1754184789,'124.232.57.22',1),(13,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NDg4NDIsIm5iZiI6MTc1NDE4NDg0MiwidWlkIjoxM30.7mand8ggHTJ40yspbrmsyVQMpZXua-97XbDiri2Wz6M',1722648842,1754184842,'220.197.21.57',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NzEwNTcsIm5iZiI6MTcyNTI2MzA1Nywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.YWmslH4ZGIl0VyNReu2qqeWGaNyYwJmqRooBuqj1_M8',1722671057,1725263057,'1.204.54.31',3),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NzEyMDcsIm5iZiI6MTc1NDIwNzIwNywidWlkIjo4fQ.iV_hZD2szdgzXM7jALBN9yyaofC0MGxLmXvYuLpi8jI',1722671207,1754207207,'1.204.54.31',1),(14,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NzI1OTMsIm5iZiI6MTc1NDIwODU5MywidWlkIjoxNH0._1zSbYjV9c5t2MlV8FAH85tkg9socbSX0i9BGpsH_SE',1722672593,1754208593,'59.36.121.176',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI2NzQxNTYsIm5iZiI6MTc1NDIxMDE1NiwidWlkIjo4fQ.vyCBq-PD8Gffses5qQ26P87Bbvh00jxBXjBdQnZ1WVU',1722674156,1754210156,'220.197.21.57',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI3NjEwMTMsIm5iZiI6MTc1NDI5NzAxMywidWlkIjo4fQ.vF-K0uLi4IOCx0xO3HMS8Dntm2M2SOAZ26mikiPcXXY',1722761013,1754297013,'220.197.21.122',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjI3NjExMzUsIm5iZiI6MTc1NDI5NzEzNSwidWlkIjo4fQ.BJntVVsJ-nzv5MG3lWo1DBFe20zc9iaWVUtgwup-u8o',1722761135,1754297135,'1.204.54.31',1),(15,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMwMDIyOTksIm5iZiI6MTc1NDUzODI5OSwidWlkIjoxNX0.X03tlO4R6Qyw9tklOHwktoByNa0tazJNizKCfGG0EBQ',1723002299,1754538299,'175.7.169.45',1),(15,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMwMDM3OTYsIm5iZiI6MTc1NDUzOTc5NiwidWlkIjoxNX0.OzcEvv8QWQ7eRPoBxV90R84vh5ZxWWL_3ClnOXg2Jds',1723003796,1754539796,'175.7.169.45',1),(11,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMwMDQwODgsIm5iZiI6MTc1NDU0MDA4OCwidWlkIjoxMX0.XnaKzJFZCCMUdOQXuIl8srLqm64gw_tBwv2umQV_FZo',1723004088,1754540088,'223.147.208.192',1),(16,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMwMDU3NTQsIm5iZiI6MTc1NDU0MTc1NCwidWlkIjoxNn0.5vTG3aKQHxwzZEBh_nBZdZgOraVnRBiHnYRU6DxX-jU',1723005754,1754541754,'175.7.169.45',1),(16,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMwMDU3NzQsIm5iZiI6MTc1NDU0MTc3NCwidWlkIjoxNn0.NzxwvDjpaMLoLJX-WOhyFx9l99oRyjTrsx-wS-PJ6Gg',1723005774,1754541774,'175.7.169.45',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMwMDU4NDcsIm5iZiI6MTcyNTU5Nzg0Nywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.tMEizxNZGbYVz-qSk_zEqpBojViX-oseWuM8pYee88E',1723005847,1725597847,'175.7.169.45',3),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMwMDg5MjQsIm5iZiI6MTc1NDU0NDkyNCwidWlkIjo4fQ.981tUYVvQBTbSa4phaWikTLI7rDSiMtjLadfaW_-fCM',1723008924,1754544924,'111.121.123.113',1),(16,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMwMjM3NzksIm5iZiI6MTc1NDU1OTc3OSwidWlkIjoxNn0.YrCntIXhQ3H3-FYvdyvtEghQNxS94tErIwL43NzBKeM',1723023779,1754559779,'175.7.169.45',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMxMDkzNzMsIm5iZiI6MTc1NDY0NTM3MywidWlkIjo4fQ.aI4nnenm303PB0VC38VZOOEOhFaKnoS432eTWxjoWbI',1723109373,1754645373,'111.121.123.113',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMxNzk3MjgsIm5iZiI6MTc1NDcxNTcyOCwidWlkIjo4fQ.7eSm8qW2ZRlzcFz20JolD9MnZFnS1XnVD4K5RYkHbCI',1723179728,1754715728,'111.121.123.113',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMyNjAzODIsIm5iZiI6MTcyNTg1MjM4Miwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.F3psNlNHJrh3dZUwz4J-5B7shwdmw3usn9moyZN4afg',1723260382,1725852382,'111.121.123.113',3),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMyNzI4MDcsIm5iZiI6MTc1NDgwODgwNywidWlkIjo4fQ.JrK82OkQYE6l8dkSWpbxK_d5aylwEtRrGe6EKYjPl_E',1723272807,1754808807,'220.197.5.134',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMyNzI4MjEsIm5iZiI6MTc1NDgwODgyMSwidWlkIjo4fQ.BmflBRr4IUebYKaQeyPn3H3hCti2moBGdqdyjfOhJPI',1723272821,1754808821,'220.197.5.134',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMyNzI4NzcsIm5iZiI6MTc1NDgwODg3NywidWlkIjo4fQ.JUim2h0jqEO58Al-vaVq534uYEYIg_JSEl2EDeQMG_k',1723272877,1754808877,'220.197.5.134',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMyNzkyMDcsIm5iZiI6MTc1NDgxNTIwNywidWlkIjo4fQ.l4IBzYqu8yIfPF2onSZ51q_7Q-iRbbkiiGyalCkZEZE',1723279207,1754815207,'220.197.5.134',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMyODE2MjgsIm5iZiI6MTc1NDgxNzYyOCwidWlkIjo4fQ.6ju5KSgqCXzfAQJwVhpdDcobY02eFRMQynogTfLcBL4',1723281628,1754817628,'220.197.5.134',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMyOTUzOTcsIm5iZiI6MTc1NDgzMTM5NywidWlkIjo4fQ.CUuAqOOJM4sIi6Nw6x4UMjLl02YoPvq4R4o5zR0YdIQ',1723295397,1754831397,'220.197.20.188',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMyOTU4MzUsIm5iZiI6MTc1NDgzMTgzNSwidWlkIjo4fQ.4WP0gGQn3bsRVaYUAIpiKZ-2VbGkcz0c2vJFVLDlYQo',1723295835,1754831835,'220.197.20.188',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMzNTc1NDIsIm5iZiI6MTc1NDg5MzU0MiwidWlkIjo4fQ.ouEyTzanNenwXqhYowtSyI0Sf5xCxvv0Aj-F2cKtlvo',1723357542,1754893542,'111.121.123.113',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMzNTc1NzIsIm5iZiI6MTc1NDg5MzU3MiwidWlkIjo4fQ.W2wIfB0datUymIOAXLO_mnNds_4VU7l6hDjQhPZQT3s',1723357572,1754893572,'111.121.123.113',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMzNTc2MTUsIm5iZiI6MTc1NDg5MzYxNSwidWlkIjo4fQ.nD0eB9COZ_bBLmfAZ3V5uDnu9NmiDxEBeRZ31ZaBLAE',1723357615,1754893615,'111.121.123.113',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMzNTc4NjgsIm5iZiI6MTc1NDg5Mzg2OCwidWlkIjo4fQ.hxv5_d0o7zZ-UncmnPVVpi_Uz36OxQzVVPOA8HeOCEk',1723357868,1754893868,'111.121.123.113',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMzNTc5NzgsIm5iZiI6MTc1NDg5Mzk3OCwidWlkIjo4fQ.OIXQn_DKm1LPTIPbvZUokFDGx8nms5TlAWkpfUpadek',1723357978,1754893978,'220.197.20.188',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMzNTgwNDUsIm5iZiI6MTc1NDg5NDA0NSwidWlkIjo4fQ.qPwf7DUrsqmRLNoPT_qOS-ROPZJqXiU6or5LlUBfUck',1723358045,1754894045,'111.121.123.113',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMzNTg1NTEsIm5iZiI6MTc1NDg5NDU1MSwidWlkIjo4fQ.feDmgLcasdHS3Ar4qaOFK1x2TpR4T94jJxgZrwyBRbA',1723358551,1754894551,'220.197.20.188',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjMzNjU1NDEsIm5iZiI6MTc1NDkwMTU0MSwidWlkIjo4fQ.4nBdIVAdT3XewxWKfxpf2wHrRqxP8BJ12RHAw3rST6g',1723365541,1754901541,'220.197.20.188',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjM1MTA5OTIsIm5iZiI6MTc1NTA0Njk5MiwidWlkIjo4fQ.h2-rm7l6z9OhjoDzlMw_fiQvCMDsaLadh-yC5jTTeUo',1723510992,1755046992,'111.121.123.113',1),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjM1MTE5MjgsIm5iZiI6MTc1NTA0NzkyOCwidWlkIjo4fQ.SddHvx_8BZZTumA2QH1ouq1wuaZTaZUrUvMx6jDte0Y',1723511928,1755047928,'111.121.123.113',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjM1MTQxOTIsIm5iZiI6MTcyNjEwNjE5Miwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.v5rfGodxHQGSMzOYw7g-PeYFy3YNTo-3ehaY0GJB05A',1723514192,1726106192,'117.188.16.101',3),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjM1MTQ4NTcsIm5iZiI6MTc1NTA1MDg1NywidWlkIjo4fQ.ymv5n6_ScTuNuv1nBjCUL2KApdgt8kBjzPSD2milwig',1723514857,1755050857,'111.121.123.113',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjM1MjM1OTMsIm5iZiI6MTcyNjExNTU5Mywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.k9QLWboQC21dZTFgzyIc-vGZ9R5WA5RatFwDBnSyhuw',1723523593,1726115593,'111.121.123.113',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjQxMTYzNDMsIm5iZiI6MTcyNjcwODM0Mywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.apw_caAlB5TO5WL5y-3ZsBNXmOrbp7gfesPZz-ngV6U',1724116343,1726708343,'111.121.118.22',3),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjQyOTczODMsIm5iZiI6MTcyNjg4OTM4Mywic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.Qz0KTZ4BUDlQNqGGtHFZMollGpOzrSiCd7mef00ZZgQ',1724297383,1726889383,'111.121.121.50',3),(8,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjQzMDkzNTksIm5iZiI6MTc1NTg0NTM1OSwidWlkIjo4fQ.7RVUpXbz1ykvuUVozeJME7pLbj-WajKJ4Ti77Iq6FQE',1724309359,1755845359,'111.121.121.50',1),(1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE3MjQ1NzU1NDgsIm5iZiI6MTcyNzE2NzU0OCwic3RhZmZfaWQiOjEsInJvbGVfaWQiOjF9.n9fdH6DeVPVBpHgKsLQ4b9zzccLNWvrQcTZj_PxnvF0',1724575548,1727167548,'111.121.121.50',3);
/*!40000 ALTER TABLE `dzuser_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzuser_xcx`
--

DROP TABLE IF EXISTS `dzuser_xcx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzuser_xcx` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '0',
  `unionid` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzuser_xcx`
--

LOCK TABLES `dzuser_xcx` WRITE;
/*!40000 ALTER TABLE `dzuser_xcx` DISABLE KEYS */;
INSERT INTO `dzuser_xcx` VALUES (7,'o_96m6yD-JsubyEZvIsyuYFtXaEY','omnca6kqPCcJmLykkhaCSivHszYc',1722591042),(9,'o_96m69bBJcNO6Xpfr3gI4l3dr5Y','omnca6s0ySwnckLgfbkpZYknuInk',1722648274),(10,'o_96m63qqqw-7JxujKG29ulJE6I8','omnca6pBj1vOzvMHDdBq58qaYiMo',1722648275),(12,'o_96m6-Rl0o2p2Oo5ts5uXpujqLw','omnca6nZViD7SRlPTBoKVDAvdD24',1722648842),(13,'o_96m63Q6JpHDM3R9gLYzYaahjYQ','omnca6hGyQZ_WjH7nyjmDwQwkQOk',1722672593),(14,'o_96m64WwixZSaRHhmUWYFF5udP8','omnca6kGTVsShLg9Vjll2HUexOtU',1723002299),(15,'o_96m6zhecaROXFaUn4DrYvN1PjE','omnca6laQIYTJDHGDHJKMtuFP9wE',1723005754);
/*!40000 ALTER TABLE `dzuser_xcx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzvisit_log`
--

DROP TABLE IF EXISTS `dzvisit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzvisit_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '访问用户',
  `visit_uid` int(11) NOT NULL DEFAULT '0' COMMENT '被访问用户',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  `update_time` bigint(12) NOT NULL DEFAULT '0',
  `is_view` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='访客记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzvisit_log`
--

LOCK TABLES `dzvisit_log` WRITE;
/*!40000 ALTER TABLE `dzvisit_log` DISABLE KEYS */;
INSERT INTO `dzvisit_log` VALUES (1,8,8,1722591483,2,1723281641,1);
/*!40000 ALTER TABLE `dzvisit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dzwithdrawal`
--

DROP TABLE IF EXISTS `dzwithdrawal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dzwithdrawal` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sn_order` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uid` int(11) NOT NULL DEFAULT '0',
  `ratio` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `pay_mode` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1 微信 2 支付宝',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT ' 1 待打款 2 打款中 3 已 完成 4 驳回',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` bigint(12) NOT NULL DEFAULT '0',
  `update_time` bigint(12) NOT NULL DEFAULT '0',
  `fees` decimal(12,2) NOT NULL DEFAULT '0.00',
  `fees_ratio` decimal(12,2) NOT NULL DEFAULT '0.00',
  `number` decimal(12,2) NOT NULL DEFAULT '0.00',
  `remark` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT ' 1 公众号 2 支付宝 3 小程序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dzwithdrawal`
--

LOCK TABLES `dzwithdrawal` WRITE;
/*!40000 ALTER TABLE `dzwithdrawal` DISABLE KEYS */;
/*!40000 ALTER TABLE `dzwithdrawal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dz_techinfo_cc'
--

--
-- Dumping routines for database 'dz_techinfo_cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-02 12:21:35
